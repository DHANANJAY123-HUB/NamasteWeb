const baseurl=[
    {
        apiurl:"http://103.104.74.215:3014/api/"
    }
]


export default baseurl ;