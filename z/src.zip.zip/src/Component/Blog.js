import React from 'react'
import Downloadapp from './Downloadapp'
import Security from './Security'
import Footer from './Footer'
import { Link } from 'react-router-dom'
import Shearchbar from './Shearchbar'

const Blog = () => {
  return (
    <div>
<div>
  {/* header section start */}
  {/* Modal */}
  
  <div className="modal fade offcanvas-modal" id="exampleModal">
    <div className="modal-dialog offcanvas-dialog">
      <div className="modal-content">
        <div className="modal-header offcanvas-header">
          <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close" />
        </div>
        <ul className="header-topbar-nav nav my-4 justify-content-center">
          <li className="topbar-nav-item">
            <a className="topbar-nav-link" href="#"><i className="icon las la-map-marker" />Store Locator</a>
          </li>
          <li className="topbar-nav-item">
            <a className="topbar-nav-link" href="#"><i className="icon las la-shipping-fast" />Track Your Order</a>
          </li>
        </ul>
        <div className="bg-white">
          <ul className="quick-links justify-content-center">
            {/* quick-link-item */}
            <li className="quick-link-item d-inline-flex">
              <span className="quick-link-icon flex-shrink-0">
                <a href="#" className="quick-link">
                  <i className="las la-user-circle" />
                </a>
              </span>
              <span className="flex-grow-1">
                <a href="#" className="my-account">My account</a>
                <a href="#" className="sign-in">Sign out</a>
              </span>
            </li>
            {/* quick-link-item end */}
            {/* quick-link-item */}
            <li className="quick-link-item d-inline-flex">
              <a href="#" className="quick-link">
                <span className="quick-link-icon flex-shrink-0">
                  <span className="badge rounded-pill bg-success">2</span>
                </span>
              </a>
            </li>
            {/* quick-link-item end */}
            {/* quick-link-item */}
            <li className="quick-link-item d-inline-flex">
              <a href="#" className="quick-link">
                <span className="quick-link-icon flex-shrink-0">
                  <i className="lar la-heart" />
                  <span className="badge rounded-pill bg-success">3</span>
                </span>
              </a>
            </li>
            {/* quick-link-item end */}
          </ul>
        </div>
        <form action="#" className="offcanvas-form">
          <input type="text" className="form-control" placeholder="Enter your search key ... " />
          <button className="btn-search btn-success" type="submit">
            <i className="las la-search" />
          </button>
        </form>
        {/* offcanvas-mobile-menu start */}
        <nav id="offcanvasNav" className="offcanvas-menu">
          <ul>
            <li>
              <a href="javascript:void(0)">Home</a>
              {/* home sub menu */}
              <ul>
                <li><a href="index.html">Home 1</a></li>
                <li><a href="index-2.html">Home 2</a></li>
                <li><a href="index-3.html">Home 3</a></li>
                <li><a href="index-4.html">Home 4</a></li>
              </ul>
              {/* home sub menu end*/}
            </li>
            <li>
              <a href="shop-grid-left-sidebar.html">shop</a>
              {/* shop mega menu */}
              <ul>
                <li>
                  <a href="#">Shop Grid</a>
                  <ul>
                    <li>
                      <a href="shop-grid-4-column.html">Shop Grid 4 Column</a>
                    </li>
                    <li>
                      <a href="shop-grid-5-column.html">Shop Grid 5 Column</a>
                    </li>
                    <li>
                      <a href="shop-grid-left-sidebar.html">Shop Grid Left Sidebar</a>
                    </li>
                    <li>
                      <a href="shop-grid-right-sidebar.html">Shop Grid Right Sidebar</a>
                    </li>
                  </ul>
                </li>
                <li>
                  <a href="#">Shop Single</a>
                  <ul>
                    <li><Link to="/single_products">Shop Single</Link></li>
                    <li>
                      <a href="single-product-configurable.html">Shop Variable</a>
                    </li>
                    <li>
                      <a href="single-product-affiliate.html">Shop Affiliate</a>
                    </li>
                    <li><a href="single-product-group.html">Shop Group</a></li>
                  </ul>
                </li>
                <li>
                  <a href="#">other pages</a>
                  <ul>
                    <li><a href="about-us.html">About Page</a></li>
                    <li><a href="cart.html">Cart Page</a></li>
                    <li><a href="checkout.html">Checkout Page</a></li>
                    <li><a href="compare.html">Compare Page</a></li>
                  </ul>
                </li>
              </ul>
              {/* shop mega menu end*/}
            </li>
            <li>
              <a href="javascript:void(0)">pages</a>
              {/* pages sub menu */}
              <ul>
                <li><a href="about-us.html">About Page</a></li>
                <li><a href="cart.html">Cart Page</a></li>
                <li><a href="checkout.html">Checkout Page</a></li>
                <li><a href="compare.html">Compare Page</a></li>
                <li><a href="login.html">Login &amp; Register Page</a></li>
                <li><a href="myaccount.html">Account Page</a></li>
                <li><a href="wishlist.html">Wishlist Page</a></li>
              </ul>
              {/* pages sub menu end*/}
            </li>
            <li>
              <a href="javascript:void(0)">Blog</a>
              {/* blog sub menu */}
              <ul>
                <li>
                  <a href="#">Blog Grid</a>
                  <ul>
                    <li>
                      <a href="blog-grid-5-column.html">Blog Grid 5 column</a>
                    </li>
                    <li>
                      <a href="blog-grid-6-column.html">Blog Grid 6 column</a>
                    </li>
                    <li>
                      <a href="blog-grid-left-sidebar.html">Blog Grid Left Sidebar</a>
                    </li>
                    <li>
                      <a href="blog-grid-right-sidebar.html">Blog Grid Right Sidebar</a>
                    </li>
                  </ul>
                </li>
                <li>
                  <a href="#">Blog List</a>
                  <ul>
                    <li>
                      <a href="blog-list-left-sidebar.html">Blog List Left Sidebar</a>
                    </li>
                    <li>
                      <a href="blog-list-right-sidebar.html">Blog List Right Sidebar</a>
                    </li>
                  </ul>
                </li>
                <li>
                  <a href="#">Blog details</a>
                  <ul>
                    <li>
                      <a href="blog-details-left-sidebar.html">Blog details Left Sidebar</a>
                    </li>
                    <li>
                      <a href="blog-details-right-sidebar.html">Blog details Right Sidbar</a>
                    </li>
                  </ul>
                </li>
              </ul>
              {/* blog sub menu end*/}
            </li>
            <li>
              <a href="contact.html">Contact</a>
            </li>
          </ul>
          <div className="offcanvas-social">
            <ul>
              <li>
                <a href="#"><i className="ion-social-facebook" /></a>
              </li>
              <li>
                <a href="#"><i className="ion-social-twitter" /></a>
              </li>
              <li>
                <a href="#"><i className="ion-social-instagram" /></a>
              </li>
              <li>
                <a href="#"><i className="ion-social-google" /></a>
              </li>
              <li>
                <a href="#"><i className="ion-social-instagram" /></a>
              </li>
            </ul>
          </div>
        </nav>
        {/* offcanvas-mobile-menu end */}
        <div className="header-top">
          <ul id="offcanvas-menu2" className="blog-ctry-menu blog-ctry-menu2">
            <li>
              <a href="javascript:void(0)">currency: USD $</a>
              <ul className="category-sub-menu">
                <li><a href="#">EUR $</a></li>
                <li><a href="#">USD $</a></li>
              </ul>
            </li>
            <li>
              <a href="javascript:void(0)"><img className="me-1" src="assets/images/icon/us-flag.jpg" alt="img" />English</a>
              <ul className="category-sub-menu">
                <li>
                  <a href="#"><img className="me-1" src="assets/images/icon/us-flag.jpg" alt="flags" />
                    English</a>
                </li>
                <li>
                  <a href="#"><img className="me-1" src="assets/images/icon/italiano-flag.jpg" alt="flags" />
                    Français</a>
                </li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>


  <header>
    <div className="header-top-bar d-none d-md-block">
      <div className="container">
        <div className="row align-items-center">
          <div className="col-3">
            <div className="social-links social-links-dark">
              <a className="social-link facebook" href="#"><i className="lab la-facebook" /></a>
              <a className="social-link twitter" href="#"><i className="lab la-twitter" /></a>
              <a className="social-link youtube" href="#"><i className="lab la-youtube" /></a>
              <a className="social-link instagram" href="#"><i className="lab la-instagram" /></a>
            </div>
          </div>
          <div className="col-9">
            <ul className="header-topbar-nav nav">
              <li className="topbar-nav-item">
                <a className="topbar-nav-link" href="#"><i className="icon las la-map-marker" />Store Locator</a>
              </li>
              <li className="topbar-nav-item">
                <a className="topbar-nav-link" href="#"><i className="icon las la-shipping-fast" />Track Your Order</a>
              </li>
              {/*   <li class="topbar-nav-item dropdown">
                          <a class="topbar-nav-link" href="#" data-bs-toggle="dropdown" id="euro"><span>EUR $</span> <i class="ion-chevron-down"></i></a>

                          <ul class="dropdown-menu" aria-labelledby="usd">
                              <li><a class="dropdown-item" href="#">EUR $</a></li>
                              <li><a class="dropdown-item" href="#">USD $</a></li>
                          </ul>
                      </li>
                      <li class="topbar-nav-item dropdown">
                          <a class="topbar-nav-link" href="#" data-bs-toggle="dropdown" id="english">
                              <img src="assets/images/icon/us-flag.jpg" alt="image_not_found" />
                              <span>English</span> <i class="ion-chevron-down"></i></a>

                          <ul class="dropdown-menu" aria-labelledby="english">
                              <li><a class="dropdown-item" href="#"><img src="assets/images/icon/us-flag.jpg" alt="us-flag">English</a></li>
                              <li><a class="dropdown-item" href="#"><img src="assets/images/icon/italiano-flag.jpg" alt="italiano-flag"> Italiano</a></li>
                          </ul>
                      </li> */}
            </ul>
          </div>
        </div>
      </div>
    </div>
    {/* header top end */}
  <Shearchbar/>
    {/* header middle end */}
    <div id="active-sticky" className="header-botom bg-dark d-none d-lg-block">
      <div className="container position-relative">
        <div className="row align-items-center">
          <div className="col-md-8">
            <ul className="main-menu">
              <li className="main-menu-item position-relative">
                <a className="main-menu-link" href="index.html">Home</a>
                {/* <ul class="sub-menu">
                              <li><a class="sub-menu-link" href="index.html">Home 1</a></li>
                              <li><a class="sub-menu-link" href="index-2.html">Home 2</a></li>
                              <li><a class="sub-menu-link" href="index-3.html">Home 3</a></li>
                              <li><a class="sub-menu-link" href="index-4.html">Home 4</a></li>
                          </ul> */}
              </li>
              <li class="main-menu-item position-static">
              <Link class="main-menu-link" to="/shop"
                >shop</Link>
            </li>

            {/* <!--   <li class="main-menu-item position-relative">
                            <a class="main-menu-link" href="#">pages<i class="ion-ios-arrow-down"></i></a>
                            <ul class="sub-menu">
                                <li><a class="sub-menu-link" href="about-us.html">About Page</a></li>
                                <li><a class="sub-menu-link" href="cart.html">Cart Page</a></li>
                                <li><a class="sub-menu-link" href="checkout.html">Checkout Page</a></li>
                                <li><a class="sub-menu-link" href="compare.html">Compare Page</a></li>
                                <li><a class="sub-menu-link" href="login.html">Login &amp; Register Page</a></li>
                                <li><a class="sub-menu-link" href="myaccount.html">Account Page</a></li>
                                <li><a class="sub-menu-link" href="wishlist.html">Wishlist Page</a></li>
                            </ul>
                        </li>
--> */}
            <li class="main-menu-item position-relative">
              <Link class="main-menu-link" to="/shop_grid4"
                >Blog</Link
              >
            </li>

            <li class="main-menu-item position-relative">
              <Link class="main-menu-link" to="/contect_us"
                >Contact us</Link
              >
            </li>
            </ul>
          </div>
          <div className="col-md-4">
            <div className="contact-info">
              <i className="las la-headset" />
              <span>Call us:</span>
              <a href="tel:0123456789">0123456789</a>
            </div>
          </div>
        </div>
      </div>
    </div>
    {/* header middle end */}
  </header>
  {/* header section end */}
  {/* main content start */}
  {/* bread crumb section start */}
  <nav className="breadcrumb-section">
    <div className="container">
      <div className="row">
        <div className="col-12">
          <ol className="breadcrumb bg-transparent m-0 p-0 align-items-center">
            <li className="breadcrumb-item"><a href="index.html">Home</a></li>
            <li className="breadcrumb-item active" aria-current="page">Fresh Food</li>
          </ol>
        </div>
      </div>
    </div>
  </nav>
  {/* bread crumb section end */}
  {/* shop product tab start*/}
  <div className="shop-product-tab section-mb">
    <div className="container">
      <div className="grid-nav-wraper bg-lighten2 mb-30">
        <div className="row align-items-center">
          <div className="col-12 col-md-6 mb-3 mb-md-0">
            <nav className="shop-grid-nav">
              <ul className="nav nav-tabs align-items-center" id="myTab" role="tablist">
                <li className="nav-item" role="presentation">
                  <a className="nav-link active" id="home-tab" data-bs-toggle="tab" href="#home" role="tab">
                    <i className="ion-grid" /></a>
                </li>
                <li className="nav-item" role="presentation">
                  <a className="nav-link" id="profile-tab" data-bs-toggle="tab" href="#profile" role="tab"><i className="ion-android-menu" /></a>
                </li>
                <li>
                  <span className="total-products text-capitalize">There are 16 products.</span>
                </li>
              </ul>
            </nav>
          </div>
          <div className="col-12 col-md-6 position-relative">
            <div className="shop-grid-button d-flex align-items-center">
              <span className="sort-by">Sort by:</span>
              <span className="chevron-arrow-down ion-android-arrow-dropdown" />
              <select className="form-select" aria-label="Default select example">
                <option selected value={1}>Relevance</option>
                <option value={2}>Name, A to Z</option>
                <option value={3}>Name, Z to A</option>
                <option value={4}>Price, low to high</option>
                <option value={5}>Price, low to low</option>
                <option value={6}>Relevance</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      <div className="tab-content" id="myTabContent">
        <div className="tab-pane fade show active" id="home" role="tabpanel">
          <div className="row grid-view mb-n7">
            <div className="col-sm-6 col-md-4 col-lg-4 col-xl-3 mb-7">
              {/* product-card start */}
              <div className="product-card">
                <span className="badge bg-success product-badge">new</span>
                <div className="product-thumb-nail">
                  <Link to="/single_products">
                    <img className="product-image" src="assets/images/products/product-1.jpg" alt="image_not_found" />
                  </Link>
                  <ul className="actions">
                    <li className="action whish-list">
                      <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                    </li>
                    {/*    <li class="action compare">
                                      <button data-bs-toggle="modal" data-bs-target="#product-modal-compare"><i class="las la-sync"></i></button>
                                  </li> */}
                    <li className="action quick-view">
                      <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                    </li>
                  </ul>
                </div>
                <div className="product-content">
                  <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                  <h3 className="product-title"><Link to="/single_products">Warburtons 9 Crumpets</Link></h3>
                  <div className="product-price-wrapp">
                    <span className="product-regular-price">$43.80</span>
                    <span className="product-price-on-sale">$39.42</span>
                    <span className="badge bg-success">-20%</span>
                  </div>
                  <div className="product-cart-btn-wrap">
                    <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                  </div>
                </div>
              </div>
              {/* product-card end */}
            </div>
            <div className="col-sm-6 col-md-4 col-lg-4 col-xl-3 mb-7">
              {/* product-card start */}
              <div className="product-card">
                <span className="badge bg-success product-badge">new</span>
                <div className="product-thumb-nail">
                  <Link to="/single_products">
                    <img className="product-image" src="assets/images/products/product-6.jpg" alt="image_not_found" />
                    <img className="product-image-hover-style" src="assets/images/products/product-6.1.jpg" alt="image_not_found" />
                  </Link>
                  <ul className="actions">
                    <li className="action whish-list">
                      <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                    </li>
                    {/*    <li class="action compare">
                                      <button data-bs-toggle="modal" data-bs-target="#product-modal-compare"><i class="las la-sync"></i></button>
                                  </li> */}
                    <li className="action quick-view">
                      <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                    </li>
                  </ul>
                </div>
                <div className="product-content">
                  <h4 className="product-sub-title"><a href="#">Fresh Fruits</a></h4>
                  <h3 className="product-title"><Link to="/single_products">Walkers Meaty Variety Crisps</Link></h3>
                  <div className="product-price-wrapp">
                    <span className="product-regular-price">$43.80</span>
                    <span className="product-price-on-sale">$39.42</span>
                    <span className="badge bg-danger">-20%</span>
                  </div>
                  <div className="product-cart-btn-wrap">
                    <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                  </div>
                </div>
              </div>
              {/* product-card end */}
            </div>
            <div className="col-sm-6 col-md-4 col-lg-4 col-xl-3 mb-7">
              {/* product-card start */}
              <div className="product-card">
                <span className="badge bg-success product-badge">new</span>
                <div className="product-thumb-nail">
                  <Link to="/single_products">
                    <img className="product-image" src="assets/images/products/product-2.jpg" alt="image_not_found" />
                    <img className="product-image-hover-style" src="assets/images/products/product-2.1.jpg" alt="image_not_found" />
                  </Link>
                  <ul className="actions">
                    <li className="action whish-list">
                      <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                    </li>
                    {/*    <li class="action compare">
                                      <button data-bs-toggle="modal" data-bs-target="#product-modal-compare"><i class="las la-sync"></i></button>
                                  </li> */}
                    <li className="action quick-view">
                      <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                    </li>
                  </ul>
                </div>
                <div className="product-content">
                  <h4 className="product-sub-title"><a href="#">Fresh Fruits</a></h4>
                  <h3 className="product-title"><Link to="/single_products">Walkers Meaty Variety Crisps</Link></h3>
                  <div className="product-price-wrapp">
                    <span className="product-regular-price">$43.80</span>
                    <span className="product-price-on-sale">$39.42</span>
                    <span className="badge bg-danger">-20%</span>
                  </div>
                  <div className="product-cart-btn-wrap">
                    <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                  </div>
                </div>
              </div>
              {/* product-card end */}
            </div>
            <div className="col-sm-6 col-md-4 col-lg-4 col-xl-3 mb-7">
              {/* product-card start */}
              <div className="product-card">
                <span className="badge bg-success product-badge">new</span>
                <div className="product-thumb-nail">
                  <Link to="/single_products">
                    <img className="product-image" src="assets/images/products/product-7.jpg" alt="image_not_found" />
                    <img className="product-image-hover-style" src="assets/images/products/product-7.1.jpg" alt="image_not_found" />
                  </Link>
                  <ul className="actions">
                    <li className="action whish-list">
                      <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                    </li>
                    {/*    <li class="action compare">
                                      <button data-bs-toggle="modal" data-bs-target="#product-modal-compare"><i class="las la-sync"></i></button>
                                  </li> */}
                    <li className="action quick-view">
                      <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                    </li>
                  </ul>
                </div>
                <div className="product-content">
                  <h4 className="product-sub-title"><a href="#">Fresh Fruits</a></h4>
                  <h3 className="product-title"><Link to="/single_products">Snacking Essentials Walnuts</Link></h3>
                  <div className="product-price-wrapp">
                    <span className="product-price-on-sale">$39.42</span>
                  </div>
                  <div className="product-cart-btn-wrap">
                    <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                  </div>
                </div>
              </div>
              {/* product-card end */}
            </div>
            <div className="col-sm-6 col-md-4 col-lg-4 col-xl-3 mb-7">
              {/* product-card start */}
              <div className="product-card">
                <span className="badge bg-success product-badge">new</span>
                <div className="product-thumb-nail">
                  <Link to="/single_products">
                    <img className="product-image" src="assets/images/products/product-3.jpg" alt="image_not_found" />
                  </Link>
                  <ul className="actions">
                    <li className="action whish-list">
                      <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                    </li>
                    {/*    <li class="action compare">
                                      <button data-bs-toggle="modal" data-bs-target="#product-modal-compare"><i class="las la-sync"></i></button>
                                  </li> */}
                    <li className="action quick-view">
                      <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                    </li>
                  </ul>
                </div>
                <div className="product-content">
                  <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                  <h3 className="product-title"><Link to="/single_products">Snacking Essentials Cashew</Link></h3>
                  <div className="product-price-wrapp">
                    <span className="product-regular-price">$43.80</span>
                    <span className="product-price-on-sale">$39.42</span>
                    <span className="badge bg-success">-20%</span>
                  </div>
                  <div className="product-cart-btn-wrap">
                    <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                  </div>
                </div>
              </div>
              {/* product-card end */}
            </div>
            <div className="col-sm-6 col-md-4 col-lg-4 col-xl-3 mb-7">
              {/* product-card start */}
              <div className="product-card">
                <span className="badge bg-success product-badge">new</span>
                <div className="product-thumb-nail">
                  <Link to="/single_products">
                    <img className="product-image" src="assets/images/products/product-8.jpg" alt="image_not_found" />
                    <img className="product-image-hover-style" src="assets/images/products/product-8.1.jpg" alt="image_not_found" />
                  </Link>
                  <ul className="actions">
                    <li className="action whish-list">
                      <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                    </li>
                    {/*    <li class="action compare">
                                      <button data-bs-toggle="modal" data-bs-target="#product-modal-compare"><i class="las la-sync"></i></button>
                                  </li> */}
                    <li className="action quick-view">
                      <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                    </li>
                  </ul>
                </div>
                <div className="product-content">
                  <h4 className="product-sub-title"><a href="#">Fresh Fruits</a></h4>
                  <h3 className="product-title"><Link to="/single_products">Skips Prawn Cocktail Flavour</Link></h3>
                  <div className="product-price-wrapp">
                    <span className="product-price-on-sale">$39.42</span>
                  </div>
                  <div className="product-cart-btn-wrap">
                    <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                  </div>
                </div>
              </div>
              {/* product-card end */}
            </div>
            <div className="col-sm-6 col-md-4 col-lg-4 col-xl-3 mb-7">
              {/* product-card start */}
              <div className="product-card">
                <span className="badge bg-success product-badge">new</span>
                <div className="product-thumb-nail">
                  <Link to="/single_products">
                    <img className="product-image" src="assets/images/products/product-4.jpg" alt="image_not_found" />
                    <img className="product-image-hover-style" src="assets/images/products/product-4.1.jpg" alt="image_not_found" />
                  </Link>
                  <ul className="actions">
                    <li className="action whish-list">
                      <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                    </li>
                    {/*    <li class="action compare">
                                      <button data-bs-toggle="modal" data-bs-target="#product-modal-compare"><i class="las la-sync"></i></button>
                                  </li> */}
                    <li className="action quick-view">
                      <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                    </li>
                  </ul>
                </div>
                <div className="product-content">
                  <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                  <h3 className="product-title"><Link to="/single_products">Salad Selection Pack</Link></h3>
                  <div className="product-price-wrapp">
                    <span className="product-regular-price">$43.80</span>
                    <span className="product-price-on-sale">$39.42</span>
                    <span className="badge bg-success">-20%</span>
                  </div>
                  <div className="product-cart-btn-wrap">
                    <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                  </div>
                </div>
              </div>
              {/* product-card end */}
            </div>
            <div className="col-sm-6 col-md-4 col-lg-4 col-xl-3 mb-7">
              {/* product-card start */}
              <div className="product-card">
                <span className="badge bg-success product-badge">new</span>
                <div className="product-thumb-nail">
                  <Link to="/single_products">
                    <img className="product-image" src="assets/images/products/product-9.jpg" alt="image_not_found" />
                    <img className="product-image-hover-style" src="assets/images/products/product-9.1.jpg" alt="image_not_found" />
                  </Link>
                  <ul className="actions">
                    <li className="action whish-list">
                      <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                    </li>
                    {/*    <li class="action compare">
                                      <button data-bs-toggle="modal" data-bs-target="#product-modal-compare"><i class="las la-sync"></i></button>
                                  </li> */}
                    <li className="action quick-view">
                      <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                    </li>
                  </ul>
                </div>
                <div className="product-content">
                  <h4 className="product-sub-title"><a href="#">Fresh Fruits</a></h4>
                  <h3 className="product-title"><Link to="/single_products">Red Seedless Grapes</Link></h3>
                  <div className="product-price-wrapp">
                    <span className="product-regular-price">$43.80</span>
                    <span className="product-price-on-sale">$39.42</span>
                  </div>
                  <div className="product-cart-btn-wrap">
                    <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                  </div>
                </div>
              </div>
              {/* product-card end */}
            </div>
            <div className="col-sm-6 col-md-4 col-lg-4 col-xl-3 mb-7">
              {/* product-card start */}
              <div className="product-card">
                <span className="badge bg-success product-badge">new</span>
                <div className="product-thumb-nail">
                  <Link to="/single_products">
                    <img className="product-image" src="assets/images/products/product-5.jpg" alt="image_not_found" />
                    <img className="product-image-hover-style" src="assets/images/products/product-5.1.jpg" alt="image_not_found" />
                  </Link>
                  <ul className="actions">
                    <li className="action whish-list">
                      <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                    </li>
                    {/*    <li class="action compare">
                                      <button data-bs-toggle="modal" data-bs-target="#product-modal-compare"><i class="las la-sync"></i></button>
                                  </li> */}
                    <li className="action quick-view">
                      <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                    </li>
                  </ul>
                </div>
                <div className="product-content">
                  <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                  <h3 className="product-title"><Link to="/single_products">Pink Lady Apples 4 Pack</Link></h3>
                  <div className="product-price-wrapp">
                    <span className="product-regular-price">$43.80</span>
                    <span className="product-price-on-sale">$39.42</span>
                    <span className="badge bg-success">-20%</span>
                  </div>
                  <div className="product-cart-btn-wrap">
                    <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                  </div>
                </div>
              </div>
              {/* product-card end */}
            </div>
            <div className="col-sm-6 col-md-4 col-lg-4 col-xl-3 mb-7">
              {/* product-card start */}
              <div className="product-card">
                <span className="badge bg-success product-badge">new</span>
                <div className="product-thumb-nail">
                  <Link to="/single_products">
                    <img className="product-image" src="assets/images/products/product-10.jpg" alt="image_not_found" />
                  </Link>
                  <ul className="actions">
                    <li className="action whish-list">
                      <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                    </li>
                    {/*    <li class="action compare">
                                      <button data-bs-toggle="modal" data-bs-target="#product-modal-compare"><i class="las la-sync"></i></button>
                                  </li> */}
                    <li className="action quick-view">
                      <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                    </li>
                  </ul>
                </div>
                <div className="product-content">
                  <h4 className="product-sub-title"><a href="#">Fresh Fruits</a></h4>
                  <h3 className="product-title"><Link to="/single_products">Mini Corn Cobs 625g</Link></h3>
                  <div className="product-price-wrapp">
                    <span className="product-price-on-sale">$39.42</span>
                  </div>
                  <div className="product-cart-btn-wrap">
                    <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                  </div>
                </div>
              </div>
              {/* product-card end */}
            </div>
            <div className="col-sm-6 col-md-4 col-lg-4 col-xl-3 mb-7">
              {/* product-card start */}
              <div className="product-card">
                <span className="badge bg-success product-badge">new</span>
                <div className="product-thumb-nail">
                  <Link to="/single_products">
                    <img className="product-image" src="assets/images/products/product-11.jpg" alt="image_not_found" />
                    <img className="product-image-hover-style" src="assets/images/products/product-11.1.jpg" alt="image_not_found" />
                  </Link>
                  <ul className="actions">
                    <li className="action whish-list">
                      <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                    </li>
                    {/*    <li class="action compare">
                                      <button data-bs-toggle="modal" data-bs-target="#product-modal-compare"><i class="las la-sync"></i></button>
                                  </li> */}
                    <li className="action quick-view">
                      <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                    </li>
                  </ul>
                </div>
                <div className="product-content">
                  <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                  <h3 className="product-title"><Link to="/single_products">lorette Sweet &amp; Crunchy</Link></h3>
                  <div className="product-price-wrapp">
                    <span className="product-price-on-sale">$39.42</span>
                  </div>
                  <div className="product-cart-btn-wrap">
                    <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                  </div>
                </div>
              </div>
              {/* product-card end */}
            </div>
            <div className="col-sm-6 col-md-4 col-lg-4 col-xl-3 mb-7">
              {/* product-card start */}
              <div className="product-card">
                <span className="badge bg-success product-badge">new</span>
                <div className="product-thumb-nail">
                  <Link to="/single_products">
                    <img className="product-image" src="assets/images/products/product-12.jpg" alt="image_not_found" />
                    <img className="product-image-hover-style" src="assets/images/products/product-12.1.jpg" alt="image_not_found" />
                  </Link>
                  <ul className="actions">
                    <li className="action whish-list">
                      <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                    </li>
                    {/*    <li class="action compare">
                                      <button data-bs-toggle="modal" data-bs-target="#product-modal-compare"><i class="las la-sync"></i></button>
                                  </li> */}
                    <li className="action quick-view">
                      <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                    </li>
                  </ul>
                </div>
                <div className="product-content">
                  <h4 className="product-sub-title"><a href="#">Fresh Fruits</a></h4>
                  <h3 className="product-title"><Link to="/single_products">Gilfresh Soup Vegetables</Link></h3>
                  <div className="product-price-wrapp">
                    <span className="product-regular-price">$43.80</span>
                    <span className="product-price-on-sale">$39.42</span>
                    <span className="badge bg-danger">-20%</span>
                  </div>
                  <div className="product-cart-btn-wrap">
                    <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                  </div>
                </div>
              </div>
              {/* product-card end */}
            </div>
            <div className="col-12 mt-7 mb-7">
              <nav aria-label="Page navigation">
                <ul className="pagination justify-content-center">
                  <li className="page-item active">
                    <a className="page-link" href="#">
                      <span className="ion-ios-arrow-left" />
                    </a>
                  </li>
                  <li className="page-item"><a className="page-link" href="#">1</a></li>
                  <li className="page-item"><a className="page-link" href="#">2</a></li>
                  <li className="page-item"><a className="page-link" href="#">3</a></li>
                  <li className="page-item">
                    <a className="page-link" href="#">
                      <span className="ion-ios-arrow-right" />
                    </a>
                  </li>
                </ul>
              </nav>
            </div>
          </div>
        </div>
        <div className="tab-pane fade" id="profile" role="tabpanel">
          <div className="row grid-view-list overflow-hidden">
            <div className="row grid-view-list mb-n7">
              <div className="col-12 mb-7">
                {/* product-card start */}
                <div className="product-card">
                  <span className="badge bg-success product-badge">new</span>
                  <div className="product-thumb-nail">
                    <Link to="/single_products">
                      <img className="product-image" src="assets/images/products/product-1.jpg" alt="image_not_found" />
                    </Link>
                    <ul className="actions">
                      <li className="action whish-list">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                      </li>
                      <li className="action compare">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-compare"><i className="las la-sync" /></button>
                      </li>
                      <li className="action quick-view">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                      </li>
                    </ul>
                  </div>
                  <div className="product-content">
                    <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                    <h3 className="product-title"><Link to="/single_products">Warburtons 9 Crumpets</Link></h3>
                    <div className="product-price-wrapp">
                      <span className="product-regular-price">$43.80</span>
                      <span className="product-price-on-sale">$39.42</span>
                      <span className="badge bg-success">-20%</span>
                    </div>
                    <p> Create a cool and sporty look with the FILA® Locker Room Varsity Jacket.
                      Comfortable cotton-blend fabrication.
                      Classic varsity jacket features brand details throughout.
                      Flat knit collar.</p>
                    <div className="product-cart-btn-wrap">
                      <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                    </div>
                  </div>
                </div>
                {/* product-card end */}
              </div>
              <div className="col-12 mb-7">
                {/* product-card start */}
                <div className="product-card">
                  <span className="badge bg-success product-badge">new</span>
                  <div className="product-thumb-nail">
                    <Link to="/single_products">
                      <img className="product-image" src="assets/images/products/product-6.jpg" alt="image_not_found" />
                      <img className="product-image-hover-style" src="assets/images/products/product-6.1.jpg" alt="image_not_found" />
                    </Link>
                    <ul className="actions">
                      <li className="action whish-list">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                      </li>
                      <li className="action compare">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-compare"><i className="las la-sync" /></button>
                      </li>
                      <li className="action quick-view">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                      </li>
                    </ul>
                  </div>
                  <div className="product-content">
                    <h4 className="product-sub-title"><a href="#">Fresh Fruits</a></h4>
                    <h3 className="product-title"><Link to="/single_products">Walkers Meaty Variety Crisps</Link></h3>
                    <div className="product-price-wrapp">
                      <span className="product-regular-price">$43.80</span>
                      <span className="product-price-on-sale">$39.42</span>
                      <span className="badge bg-danger">-20%</span>
                    </div>
                    <p> Create a cool and sporty look with the FILA® Locker Room Varsity Jacket.
                      Comfortable cotton-blend fabrication.
                      Classic varsity jacket features brand details throughout.
                      Flat knit collar.</p>
                    <div className="product-cart-btn-wrap">
                      <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                    </div>
                  </div>
                </div>
                {/* product-card end */}
              </div>
              <div className="col-12 mb-7">
                {/* product-card start */}
                <div className="product-card">
                  <span className="badge bg-success product-badge">new</span>
                  <div className="product-thumb-nail">
                    <Link to="/single_products">
                      <img className="product-image" src="assets/images/products/product-2.jpg" alt="image_not_found" />
                      <img className="product-image-hover-style" src="assets/images/products/product-2.1.jpg" alt="image_not_found" />
                    </Link>
                    <ul className="actions">
                      <li className="action whish-list">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                      </li>
                      <li className="action compare">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-compare"><i className="las la-sync" /></button>
                      </li>
                      <li className="action quick-view">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                      </li>
                    </ul>
                  </div>
                  <div className="product-content">
                    <h4 className="product-sub-title"><a href="#">Fresh Fruits</a></h4>
                    <h3 className="product-title"><Link to="/single_products">Walkers Meaty Variety Crisps</Link></h3>
                    <div className="product-price-wrapp">
                      <span className="product-regular-price">$43.80</span>
                      <span className="product-price-on-sale">$39.42</span>
                      <span className="badge bg-danger">-20%</span>
                    </div>
                    <p> Create a cool and sporty look with the FILA® Locker Room Varsity Jacket.
                      Comfortable cotton-blend fabrication.
                      Classic varsity jacket features brand details throughout.
                      Flat knit collar.</p>
                    <div className="product-cart-btn-wrap">
                      <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                    </div>
                  </div>
                </div>
                {/* product-card end */}
              </div>
              <div className="col-12 mb-7">
                {/* product-card start */}
                <div className="product-card">
                  <span className="badge bg-success product-badge">new</span>
                  <div className="product-thumb-nail">
                    <Link to="/single_products">
                      <img className="product-image" src="assets/images/products/product-7.jpg" alt="image_not_found" />
                      <img className="product-image-hover-style" src="assets/images/products/product-7.1.jpg" alt="image_not_found" />
                    </Link>
                    <ul className="actions">
                      <li className="action whish-list">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                      </li>
                      <li className="action compare">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-compare"><i className="las la-sync" /></button>
                      </li>
                      <li className="action quick-view">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                      </li>
                    </ul>
                  </div>
                  <div className="product-content">
                    <h4 className="product-sub-title"><a href="#">Fresh Fruits</a></h4>
                    <h3 className="product-title"><Link to="/single_products">Snacking Essentials Walnuts</Link></h3>
                    <div className="product-price-wrapp">
                      <span className="product-price-on-sale">$39.42</span>
                    </div>
                    <p> Create a cool and sporty look with the FILA® Locker Room Varsity Jacket.
                      Comfortable cotton-blend fabrication.
                      Classic varsity jacket features brand details throughout.
                      Flat knit collar.</p>
                    <div className="product-cart-btn-wrap">
                      <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                    </div>
                  </div>
                </div>
                {/* product-card end */}
              </div>
              <div className="col-12 mb-7">
                {/* product-card start */}
                <div className="product-card">
                  <span className="badge bg-success product-badge">new</span>
                  <div className="product-thumb-nail">
                    <Link to="/single_products">
                      <img className="product-image" src="assets/images/products/product-3.jpg" alt="image_not_found" />
                    </Link>
                    <ul className="actions">
                      <li className="action whish-list">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                      </li>
                      <li className="action compare">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-compare"><i className="las la-sync" /></button>
                      </li>
                      <li className="action quick-view">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                      </li>
                    </ul>
                  </div>
                  <div className="product-content">
                    <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                    <h3 className="product-title"><Link to="/single_products">Snacking Essentials Cashew</Link></h3>
                    <div className="product-price-wrapp">
                      <span className="product-regular-price">$43.80</span>
                      <span className="product-price-on-sale">$39.42</span>
                      <span className="badge bg-success">-20%</span>
                    </div>
                    <p> Create a cool and sporty look with the FILA® Locker Room Varsity Jacket.
                      Comfortable cotton-blend fabrication.
                      Classic varsity jacket features brand details throughout.
                      Flat knit collar.</p>
                    <div className="product-cart-btn-wrap">
                      <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                    </div>
                  </div>
                </div>
                {/* product-card end */}
              </div>
              <div className="col-12 mb-7">
                {/* product-card start */}
                <div className="product-card">
                  <span className="badge bg-success product-badge">new</span>
                  <div className="product-thumb-nail">
                    <Link to="/single_products">
                      <img className="product-image" src="assets/images/products/product-8.jpg" alt="image_not_found" />
                      <img className="product-image-hover-style" src="assets/images/products/product-8.1.jpg" alt="image_not_found" />
                    </Link>
                    <ul className="actions">
                      <li className="action whish-list">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                      </li>
                      <li className="action compare">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-compare"><i className="las la-sync" /></button>
                      </li>
                      <li className="action quick-view">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                      </li>
                    </ul>
                  </div>
                  <div className="product-content">
                    <h4 className="product-sub-title"><a href="#">Fresh Fruits</a></h4>
                    <h3 className="product-title"><Link to="/single_products">Skips Prawn Cocktail Flavour</Link></h3>
                    <div className="product-price-wrapp">
                      <span className="product-price-on-sale">$39.42</span>
                    </div>
                    <p> Create a cool and sporty look with the FILA® Locker Room Varsity Jacket.
                      Comfortable cotton-blend fabrication.
                      Classic varsity jacket features brand details throughout.
                      Flat knit collar.</p>
                    <div className="product-cart-btn-wrap">
                      <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                    </div>
                  </div>
                </div>
                {/* product-card end */}
              </div>
              <div className="col-12 mb-7">
                {/* product-card start */}
                <div className="product-card">
                  <span className="badge bg-success product-badge">new</span>
                  <div className="product-thumb-nail">
                    <Link to="/single_products">
                      <img className="product-image" src="assets/images/products/product-4.jpg" alt="image_not_found" />
                      <img className="product-image-hover-style" src="assets/images/products/product-4.1.jpg" alt="image_not_found" />
                    </Link>
                    <ul className="actions">
                      <li className="action whish-list">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                      </li>
                      <li className="action compare">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-compare"><i className="las la-sync" /></button>
                      </li>
                      <li className="action quick-view">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                      </li>
                    </ul>
                  </div>
                  <div className="product-content">
                    <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                    <h3 className="product-title"><Link to="/single_products">Salad Selection Pack</Link></h3>
                    <div className="product-price-wrapp">
                      <span className="product-regular-price">$43.80</span>
                      <span className="product-price-on-sale">$39.42</span>
                      <span className="badge bg-success">-20%</span>
                    </div>
                    <p> Create a cool and sporty look with the FILA® Locker Room Varsity Jacket.
                      Comfortable cotton-blend fabrication.
                      Classic varsity jacket features brand details throughout.
                      Flat knit collar.</p>
                    <div className="product-cart-btn-wrap">
                      <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                    </div>
                  </div>
                </div>
                {/* product-card end */}
              </div>
              <div className="col-12 mb-7">
                {/* product-card start */}
                <div className="product-card">
                  <span className="badge bg-success product-badge">new</span>
                  <div className="product-thumb-nail">
                    <Link to="/single_products">
                      <img className="product-image" src="assets/images/products/product-9.jpg" alt="image_not_found" />
                      <img className="product-image-hover-style" src="assets/images/products/product-9.1.jpg" alt="image_not_found" />
                    </Link>
                    <ul className="actions">
                      <li className="action whish-list">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                      </li>
                      <li className="action compare">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-compare"><i className="las la-sync" /></button>
                      </li>
                      <li className="action quick-view">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                      </li>
                    </ul>
                  </div>
                  <div className="product-content">
                    <h4 className="product-sub-title"><a href="#">Fresh Fruits</a></h4>
                    <h3 className="product-title"><Link to="/single_products">Red Seedless Grapes</Link></h3>
                    <div className="product-price-wrapp">
                      <span className="product-regular-price">$43.80</span>
                      <span className="product-price-on-sale">$39.42</span>
                    </div>
                    <p> Create a cool and sporty look with the FILA® Locker Room Varsity Jacket.
                      Comfortable cotton-blend fabrication.
                      Classic varsity jacket features brand details throughout.
                      Flat knit collar.</p>
                    <div className="product-cart-btn-wrap">
                      <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                    </div>
                  </div>
                </div>
                {/* product-card end */}
              </div>
              <div className="col-12 mb-7">
                {/* product-card start */}
                <div className="product-card">
                  <span className="badge bg-success product-badge">new</span>
                  <div className="product-thumb-nail">
                    <Link to="/single_products">
                      <img className="product-image" src="assets/images/products/product-5.jpg" alt="image_not_found" />
                      <img className="product-image-hover-style" src="assets/images/products/product-5.1.jpg" alt="image_not_found" />
                    </Link>
                    <ul className="actions">
                      <li className="action whish-list">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                      </li>
                      <li className="action compare">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-compare"><i className="las la-sync" /></button>
                      </li>
                      <li className="action quick-view">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                      </li>
                    </ul>
                  </div>
                  <div className="product-content">
                    <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                    <h3 className="product-title"><Link to="/single_products">Pink Lady Apples 4 Pack</Link></h3>
                    <div className="product-price-wrapp">
                      <span className="product-regular-price">$43.80</span>
                      <span className="product-price-on-sale">$39.42</span>
                      <span className="badge bg-success">-20%</span>
                    </div>
                    <p> Create a cool and sporty look with the FILA® Locker Room Varsity Jacket.
                      Comfortable cotton-blend fabrication.
                      Classic varsity jacket features brand details throughout.
                      Flat knit collar.</p>
                    <div className="product-cart-btn-wrap">
                      <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                    </div>
                  </div>
                </div>
                {/* product-card end */}
              </div>
              <div className="col-12 mb-7">
                {/* product-card start */}
                <div className="product-card">
                  <span className="badge bg-success product-badge">new</span>
                  <div className="product-thumb-nail">
                    <Link to="/single_products">
                      <img className="product-image" src="assets/images/products/product-10.jpg" alt="image_not_found" />
                    </Link>
                    <ul className="actions">
                      <li className="action whish-list">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                      </li>
                      <li className="action compare">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-compare"><i className="las la-sync" /></button>
                      </li>
                      <li className="action quick-view">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                      </li>
                    </ul>
                  </div>
                  <div className="product-content">
                    <h4 className="product-sub-title"><a href="#">Fresh Fruits</a></h4>
                    <h3 className="product-title"><Link to="/single_products">Mini Corn Cobs 625g</Link></h3>
                    <div className="product-price-wrapp">
                      <span className="product-price-on-sale">$39.42</span>
                    </div>
                    <p> Create a cool and sporty look with the FILA® Locker Room Varsity Jacket.
                      Comfortable cotton-blend fabrication.
                      Classic varsity jacket features brand details throughout.
                      Flat knit collar.</p>
                    <div className="product-cart-btn-wrap">
                      <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                    </div>
                  </div>
                </div>
                {/* product-card end */}
              </div>
              <div className="col-12 mb-7">
                {/* product-card start */}
                <div className="product-card">
                  <span className="badge bg-success product-badge">new</span>
                  <div className="product-thumb-nail">
                    <Link to="/single_products">
                      <img className="product-image" src="assets/images/products/product-11.jpg" alt="image_not_found" />
                      <img className="product-image-hover-style" src="assets/images/products/product-11.1.jpg" alt="image_not_found" />
                    </Link>
                    <ul className="actions">
                      <li className="action whish-list">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                      </li>
                      <li className="action compare">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-compare"><i className="las la-sync" /></button>
                      </li>
                      <li className="action quick-view">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                      </li>
                    </ul>
                  </div>
                  <div className="product-content">
                    <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                    <h3 className="product-title"><Link to="/single_products">lorette Sweet &amp; Crunchy</Link></h3>
                    <div className="product-price-wrapp">
                      <span className="product-price-on-sale">$39.42</span>
                    </div>
                    <p> Create a cool and sporty look with the FILA® Locker Room Varsity Jacket.
                      Comfortable cotton-blend fabrication.
                      Classic varsity jacket features brand details throughout.
                      Flat knit collar.</p>
                    <div className="product-cart-btn-wrap">
                      <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                    </div>
                  </div>
                </div>
                {/* product-card end */}
              </div>
              <div className="col-12 mb-7">
                {/* product-card start */}
                <div className="product-card">
                  <span className="badge bg-success product-badge">new</span>
                  <div className="product-thumb-nail">
                    <Link to="/single_products">
                      <img className="product-image" src="assets/images/products/product-12.jpg" alt="image_not_found" />
                      <img className="product-image-hover-style" src="assets/images/products/product-12.1.jpg" alt="image_not_found" />
                    </Link>
                    <ul className="actions">
                      <li className="action whish-list">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                      </li>
                      <li className="action compare">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-compare"><i className="las la-sync" /></button>
                      </li>
                      <li className="action quick-view">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                      </li>
                    </ul>
                  </div>
                  <div className="product-content">
                    <h4 className="product-sub-title"><a href="#">Fresh Fruits</a></h4>
                    <h3 className="product-title"><Link to="/single_products">Gilfresh Soup Vegetables</Link></h3>
                    <div className="product-price-wrapp">
                      <span className="product-regular-price">$43.80</span>
                      <span className="product-price-on-sale">$39.42</span>
                      <span className="badge bg-danger">-20%</span>
                    </div>
                    <p> Create a cool and sporty look with the FILA® Locker Room Varsity Jacket.
                      Comfortable cotton-blend fabrication.
                      Classic varsity jacket features brand details throughout.
                      Flat knit collar.</p>
                    <div className="product-cart-btn-wrap">
                      <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                    </div>
                  </div>
                </div>
                {/* product-card end */}
              </div>
              <div className="col-12 mb-7">
                {/* product-card start */}
                <div className="product-card">
                  <span className="badge bg-success product-badge">new</span>
                  <div className="product-thumb-nail">
                    <Link to="/single_products">
                      <img className="product-image" src="assets/images/products/product-4.jpg" alt="image_not_found" />
                      <img className="product-image-hover-style" src="assets/images/products/product-4.1.jpg" alt="image_not_found" />
                    </Link>
                    <ul className="actions">
                      <li className="action whish-list">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                      </li>
                      <li className="action compare">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-compare"><i className="las la-sync" /></button>
                      </li>
                      <li className="action quick-view">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                      </li>
                    </ul>
                  </div>
                  <div className="product-content">
                    <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                    <h3 className="product-title"><Link to="/single_products">Salad Selection Pack</Link></h3>
                    <div className="product-price-wrapp">
                      <span className="product-regular-price">$43.80</span>
                      <span className="product-price-on-sale">$39.42</span>
                      <span className="badge bg-success">-20%</span>
                    </div>
                    <p> Create a cool and sporty look with the FILA® Locker Room Varsity Jacket.
                      Comfortable cotton-blend fabrication.
                      Classic varsity jacket features brand details throughout.
                      Flat knit collar.</p>
                    <div className="product-cart-btn-wrap">
                      <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                    </div>
                  </div>
                </div>
                {/* product-card end */}
              </div>
              <div className="col-12 mb-7">
                {/* product-card start */}
                <div className="product-card">
                  <span className="badge bg-success product-badge">new</span>
                  <div className="product-thumb-nail">
                    <Link to="/single_products">
                      <img className="product-image" src="assets/images/products/product-9.jpg" alt="image_not_found" />
                      <img className="product-image-hover-style" src="assets/images/products/product-9.1.jpg" alt="image_not_found" />
                    </Link>
                    <ul className="actions">
                      <li className="action whish-list">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                      </li>
                      <li className="action compare">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-compare"><i className="las la-sync" /></button>
                      </li>
                      <li className="action quick-view">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                      </li>
                    </ul>
                  </div>
                  <div className="product-content">
                    <h4 className="product-sub-title"><a href="#">Fresh Fruits</a></h4>
                    <h3 className="product-title"><Link to="/single_products">Red Seedless Grapes</Link></h3>
                    <div className="product-price-wrapp">
                      <span className="product-regular-price">$43.80</span>
                      <span className="product-price-on-sale">$39.42</span>
                    </div>
                    <p> Create a cool and sporty look with the FILA® Locker Room Varsity Jacket.
                      Comfortable cotton-blend fabrication.
                      Classic varsity jacket features brand details throughout.
                      Flat knit collar.</p>
                    <div className="product-cart-btn-wrap">
                      <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                    </div>
                  </div>
                </div>
                {/* product-card end */}
              </div>
              <div className="col-12 mb-7">
                <nav aria-label="Page navigation">
                  <ul className="pagination justify-content-center">
                    <li className="page-item active">
                      <a className="page-link" href="#">
                        <span className="ion-ios-arrow-left" />
                      </a>
                    </li>
                    <li className="page-item"><a className="page-link" href="#">1</a></li>
                    <li className="page-item"><a className="page-link" href="#">2</a></li>
                    <li className="page-item"><a className="page-link" href="#">3</a></li>
                    <li className="page-item">
                      <a className="page-link" href="#">
                        <span className="ion-ios-arrow-right" />
                      </a>
                    </li>
                  </ul>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>






  <Downloadapp/>
  <Security/>
  <Footer/>






</div>
<div className="modal fade" id="addto-cart-modal">
<div className="modal-dialog modal-dialog-centered">
  <div className="modal-content">
    <div className="modal-header bg-dark border-bottom-0 justify-content-center">
      <span className="ion-android-done me-5" />
      <h4 className="modal-title text-center">Product successfully added to your shopping cart</h4>
      <button type="button" className="btn-close position-absolute" data-bs-dismiss="modal" aria-label="Close">×</button>
    </div>
    <div className="modal-body p-5">
      <div className="row align-items-center align-items-lg-start">
        <div className="col-lg-5">
          <div className="row align-items-center align-items-lg-start">
            <div className="col-md-6">
              <img className="product-image" src="assets/images/products/product-13.jpg" alt="images_not_found" />
            </div>
            <div className="col-md-6">
              <h6 className="product-name">Snacking Essentials Walnuts</h6>
              <ul className="quntity-list">
                <li>$23.06</li>
                {/* <li>Color: White</li> */}
                <li>Quantity:1</li>
              </ul>
            </div>
          </div>
        </div>
        <div className="col-lg-7">
          <div className="cart-content">
            <p className="title">There are 3 items in your cart.</p>
            <p><span>Total products:</span>$23.06</p>
            <p><span>Total shipping:</span>Free</p>
            <p><span>Taxes:</span> $0.00</p>
            <p><span>Total:</span> $23.06 (tax excl.)</p>
            <div className="cart-content-btn">
              <button className="btn btn-sm btn-dark me-1 mt-3 mt-sm-0" data-bs-dismiss="modal">Continue
                shopping</button>
              <button className="btn btn-sm btn-dark mt-3 mt-sm-0"><Link to="/checkout" style={{color : 'white'}}>Proceed to
                  checkout</Link></button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
    </div>
  )
}

export default Blog