import React from 'react'
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

function Fruits() {
  var settingsss = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1
  };
  return (
    <div>
    
    <section className="product-carousel">
<div className="container position-relative">
  <div className="row">
    <div className="section-title">
      <h2 className="title">Fruits and Vegetables</h2>
    </div>
  </div>
  <div className="row">
    <div className="col-12">
      <div className="custom-container">
        <div className="custom-col-left">
          <aside className="sidebar-widgets">
            <div className="widget">
              <div className="product-box">
                <a href="shop-grid-4-column.html" className="banner-box-animation">
                  <img src="assets/images/banner/sidebar1.jpg" alt="images_not_found" />
                </a>
                <ul className="sidebar-menu">
                  <li className="sidebar-menu-item"><a className="sidebar-menu-nav-link" href="#">Bananas</a></li>
                  <li className="sidebar-menu-item"><a className="sidebar-menu-nav-link" href="#">Apples Pears</a></li>
                  <li className="sidebar-menu-item"><a className="sidebar-menu-nav-link" href="#">Berries Cherries</a></li>
                  <li className="sidebar-menu-item"><a className="sidebar-menu-nav-link" href="#">Oranges Citrus Fruit</a>
                  </li>
                  <li className="sidebar-menu-item"><a className="sidebar-menu-nav-link" href="#">Onions Leeks</a></li>
                  <li className="sidebar-menu-item"><a className="sidebar-menu-nav-link" href="#">Carrots Root
                    Vegetables</a>
                  </li>
                  <li className="sidebar-menu-item"><a className="sidebar-menu-nav-link" href="#">Tomatoes</a></li>
                </ul>
              </div>
            </div>
          </aside>
        </div>

        <div className="custom-col-right">



          <Slider {...settingsss}>

            {/* swiper-slide start */}
            <div className="product-carousel-item swiper-slide">
              {/* product-card-list start */}
              <div className="product-card-list">
                {/* product-card start */}
                <div className="product-card">
                  <span className="badge bg-success product-badge">new</span>
                  <div className="product-thumb-nail">
                    <a href="single-product.html">
                      <img className="product-image" src="assets/images/products/product-1.jpg" alt="image_not_found" />
                    </a>
                    <ul className="actions">
                      <li className="action whish-list">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                      </li>
                      <li className="action compare">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-compare" />
                      </li>
                      <li className="action quick-view">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                      </li>
                    </ul>
                  </div>
                  <div className="product-content">
                    <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                    <h3 className="product-title"><a href="single-product.html">Warburtons 9 Crumpets</a></h3>
                    <div className="product-price-wrapp">
                      <span className="product-regular-price">$43.80</span>
                      <span className="product-price-on-sale">$39.42</span>
                      <span className="badge bg-success">-20%</span>
                    </div>
                    <div className="product-cart-btn-wrap">
                      <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                    </div>
                  </div>
                </div>
                {/* product-card end */}
              </div>
              {/* product-card-list end */}
              {/* product-card-list start */}
              <div className="product-card-list">
                {/* product-card start */}
                <div className="product-card">
                  <span className="badge bg-success product-badge">new</span>
                  <div className="product-thumb-nail">
                    <a href="single-product.html">
                      <img className="product-image" src="assets/images/products/product-6.jpg" alt="image_not_found" />
                      <img className="product-image-hover-style" src="assets/images/products/product-6.1.jpg" alt="image_not_found" />
                    </a>
                    <ul className="actions">
                      <li className="action whish-list">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                      </li>
                      <li className="action compare">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-compare" />
                      </li>
                      <li className="action quick-view">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                      </li>
                    </ul>
                  </div>
                  <div className="product-content">
                    <h4 className="product-sub-title"><a href="#">Fresh Fruits</a></h4>
                    <h3 className="product-title"><a href="single-product.html">Walkers Meaty Variety Crisps</a></h3>
                    <div className="product-price-wrapp">
                      <span className="product-regular-price">$43.80</span>
                      <span className="product-price-on-sale">$39.42</span>
                      <span className="badge bg-danger">-20%</span>
                    </div>
                    <div className="product-cart-btn-wrap">
                      <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                    </div>
                  </div>
                </div>
                {/* product-card end */}
              </div>
              {/* product-card-list end */}
            </div>
            {/* swiper-slide end*/}
            {/* swiper-slide start */}
            <div className="product-carousel-item swiper-slide">
              {/* product-card-list start */}
              <div className="product-card-list">
                {/* product-card start */}
                <div className="product-card">
                  <span className="badge bg-success product-badge">new</span>
                  <div className="product-thumb-nail">
                    <a href="single-product.html">
                      <img className="product-image" src="assets/images/products/product-2.jpg" alt="image_not_found" />
                      <img className="product-image-hover-style" src="assets/images/products/product-2.1.jpg" alt="image_not_found" />
                    </a>
                    <ul className="actions">
                      <li className="action whish-list">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                      </li>
                      <li className="action compare">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-compare" />
                      </li>
                      <li className="action quick-view">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                      </li>
                    </ul>
                  </div>
                  <div className="product-content">
                    <h4 className="product-sub-title"><a href="#">Fresh Fruits</a></h4>
                    <h3 className="product-title"><a href="single-product.html">Walkers Meaty Variety Crisps</a></h3>
                    <div className="product-price-wrapp">
                      <span className="product-regular-price">$43.80</span>
                      <span className="product-price-on-sale">$39.42</span>
                      <span className="badge bg-danger">-20%</span>
                    </div>
                    <div className="product-cart-btn-wrap">
                      <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                    </div>
                  </div>
                </div>
                {/* product-card end */}
              </div>
              {/* product-card-list end */}
              {/* product-card-list start */}
              <div className="product-card-list">
                {/* product-card start */}
                <div className="product-card">
                  <span className="badge bg-success product-badge">new</span>
                  <div className="product-thumb-nail">
                    <a href="single-product.html">
                      <img className="product-image" src="assets/images/products/product-7.jpg" alt="image_not_found" />
                      <img className="product-image-hover-style" src="assets/images/products/product-7.1.jpg" alt="image_not_found" />
                    </a>
                    <ul className="actions">
                      <li className="action whish-list">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                      </li>
                      <li className="action compare">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-compare" />
                      </li>
                      <li className="action quick-view">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                      </li>
                    </ul>
                  </div>
                  <div className="product-content">
                    <h4 className="product-sub-title"><a href="#">Fresh Fruits</a></h4>
                    <h3 className="product-title"><a href="single-product.html">Snacking Essentials Walnuts</a></h3>
                    <div className="product-price-wrapp">
                      <span className="product-price-on-sale">$39.42</span>
                    </div>
                    <div className="product-cart-btn-wrap">
                      <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                    </div>
                  </div>
                </div>
                {/* product-card end */}
              </div>
              {/* product-card-list end */}
            </div>
            {/* swiper-slide end*/}
            {/* swiper-slide start */}
            <div className="product-carousel-item swiper-slide">
              {/* product-card-list start */}
              <div className="product-card-list">
                {/* product-card start */}
                <div className="product-card">
                  <span className="badge bg-success product-badge">new</span>
                  <div className="product-thumb-nail">
                    <a href="single-product.html">
                      <img className="product-image" src="assets/images/products/product-3.jpg" alt="image_not_found" />
                    </a>
                    <ul className="actions">
                      <li className="action whish-list">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                      </li>
                      <li className="action compare">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-compare" />
                      </li>
                      <li className="action quick-view">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                      </li>
                    </ul>
                  </div>
                  <div className="product-content">
                    <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                    <h3 className="product-title"><a href="single-product.html">Snacking Essentials Cashew</a></h3>
                    <div className="product-price-wrapp">
                      <span className="product-regular-price">$43.80</span>
                      <span className="product-price-on-sale">$39.42</span>
                      <span className="badge bg-success">-20%</span>
                    </div>
                    <div className="product-cart-btn-wrap">
                      <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                    </div>
                  </div>
                </div>
                {/* product-card end */}
              </div>
              {/* product-card-list end */}
              {/* product-card-list start */}
              <div className="product-card-list">
                {/* product-card start */}
                <div className="product-card">
                  <span className="badge bg-success product-badge">new</span>
                  <div className="product-thumb-nail">
                    <a href="single-product.html">
                      <img className="product-image" src="assets/images/products/product-8.jpg" alt="image_not_found" />
                      <img className="product-image-hover-style" src="assets/images/products/product-8.1.jpg" alt="image_not_found" />
                    </a>
                    <ul className="actions">
                      <li className="action whish-list">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                      </li>
                      <li className="action compare">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-compare" />
                      </li>
                      <li className="action quick-view">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                      </li>
                    </ul>
                  </div>
                  <div className="product-content">
                    <h4 className="product-sub-title"><a href="#">Fresh Fruits</a></h4>
                    <h3 className="product-title"><a href="single-product.html">Skips Prawn Cocktail Flavour</a></h3>
                    <div className="product-price-wrapp">
                      <span className="product-price-on-sale">$39.42</span>
                    </div>
                    <div className="product-cart-btn-wrap">
                      <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                    </div>
                  </div>
                </div>
                {/* product-card end */}
              </div>
              {/* product-card-list end */}
            </div>
            {/* swiper-slide end*/}
            {/* swiper-slide start */}
            <div className="product-carousel-item swiper-slide">
              {/* product-card-list start */}
              <div className="product-card-list">
                {/* product-card start */}
                <div className="product-card">
                  <span className="badge bg-success product-badge">new</span>
                  <div className="product-thumb-nail">
                    <a href="single-product.html">
                      <img className="product-image" src="assets/images/products/product-4.jpg" alt="image_not_found" />
                      <img className="product-image-hover-style" src="assets/images/products/product-4.1.jpg" alt="image_not_found" />
                    </a>
                    <ul className="actions">
                      <li className="action whish-list">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                      </li>
                      <li className="action compare">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-compare" />
                      </li>
                      <li className="action quick-view">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                      </li>
                    </ul>
                  </div>
                  <div className="product-content">
                    <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                    <h3 className="product-title"><a href="single-product.html">Salad Selection Pack</a></h3>
                    <div className="product-price-wrapp">
                      <span className="product-regular-price">$43.80</span>
                      <span className="product-price-on-sale">$39.42</span>
                      <span className="badge bg-success">-20%</span>
                    </div>
                    <div className="product-cart-btn-wrap">
                      <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                    </div>
                  </div>
                </div>
                {/* product-card end */}
              </div>
              {/* product-card-list end */}
              {/* product-card-list start */}
              <div className="product-card-list">
                {/* product-card start */}
                <div className="product-card">
                  <span className="badge bg-success product-badge">new</span>
                  <div className="product-thumb-nail">
                    <a href="single-product.html">
                      <img className="product-image" src="assets/images/products/product-9.jpg" alt="image_not_found" />
                      <img className="product-image-hover-style" src="assets/images/products/product-9.1.jpg" alt="image_not_found" />
                    </a>
                    <ul className="actions">
                      <li className="action whish-list">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                      </li>
                      <li className="action compare">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-compare" />
                      </li>
                      <li className="action quick-view">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                      </li>
                    </ul>
                  </div>
                  <div className="product-content">
                    <h4 className="product-sub-title"><a href="#">Fresh Fruits</a></h4>
                    <h3 className="product-title"><a href="single-product.html">Red Seedless Grapes</a></h3>
                    <div className="product-price-wrapp">
                      <span className="product-regular-price">$43.80</span>
                      <span className="product-price-on-sale">$39.42</span>
                    </div>
                    <div className="product-cart-btn-wrap">
                      <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                    </div>
                  </div>
                </div>
                {/* product-card end */}
              </div>
              {/* product-card-list end */}
            </div>
            {/* swiper-slide end*/}
            {/* swiper-slide start */}
            <div className="product-carousel-item swiper-slide">
              {/* product-card-list start */}
              <div className="product-card-list">
                {/* product-card start */}
                <div className="product-card">
                  <span className="badge bg-success product-badge">new</span>
                  <div className="product-thumb-nail">
                    <a href="single-product.html">
                      <img className="product-image" src="assets/images/products/product-5.jpg" alt="image_not_found" />
                      <img className="product-image-hover-style" src="assets/images/products/product-5.1.jpg" alt="image_not_found" />
                    </a>
                    <ul className="actions">
                      <li className="action whish-list">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                      </li>
                      <li className="action compare">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-compare" />
                      </li>
                      <li className="action quick-view">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                      </li>
                    </ul>
                  </div>
                  <div className="product-content">
                    <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                    <h3 className="product-title"><a href="single-product.html">Pink Lady Apples 4 Pack</a></h3>
                    <div className="product-price-wrapp">
                      <span className="product-regular-price">$43.80</span>
                      <span className="product-price-on-sale">$39.42</span>
                      <span className="badge bg-success">-20%</span>
                    </div>
                    <div className="product-cart-btn-wrap">
                      <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                    </div>
                  </div>
                </div>
                {/* product-card end */}
              </div>
              {/* product-card-list end */}
              {/* product-card-list start */}
              <div className="product-card-list">
                {/* product-card start */}
                <div className="product-card">
                  <span className="badge bg-success product-badge">new</span>
                  <div className="product-thumb-nail">
                    <a href="single-product.html">
                      <img className="product-image" src="assets/images/products/product-10.jpg" alt="image_not_found" />
                    </a>
                    <ul className="actions">
                      <li className="action whish-list">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                      </li>
                      <li className="action compare">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-compare" />
                      </li>
                      <li className="action quick-view">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                      </li>
                    </ul>
                  </div>
                  <div className="product-content">
                    <h4 className="product-sub-title"><a href="#">Fresh Fruits</a></h4>
                    <h3 className="product-title"><a href="single-product.html">Mini Corn Cobs 625g</a></h3>
                    <div className="product-price-wrapp">
                      <span className="product-price-on-sale">$39.42</span>
                    </div>
                    <div className="product-cart-btn-wrap">
                      <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                    </div>
                  </div>
                </div>
                {/* product-card end */}
              </div>
              {/* product-card-list end */}
            </div>
            {/* swiper-slide end*/}
            {/* swiper-slide start */}
            <div className="product-carousel-item swiper-slide">
              {/* product-card-list start */}
              <div className="product-card-list">
                {/* product-card start */}
                <div className="product-card">
                  <span className="badge bg-success product-badge">new</span>
                  <div className="product-thumb-nail">
                    <a href="single-product.html">
                      <img className="product-image" src="assets/images/products/product-11.jpg" alt="image_not_found" />
                      <img className="product-image-hover-style" src="assets/images/products/product-11.1.jpg" alt="image_not_found" />
                    </a>
                    <ul className="actions">
                      <li className="action whish-list">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                      </li>
                      <li className="action compare">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-compare" />
                      </li>
                      <li className="action quick-view">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                      </li>
                    </ul>
                  </div>
                  <div className="product-content">
                    <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                    <h3 className="product-title"><a href="single-product.html">lorette Sweet &amp; Crunchy</a></h3>
                    <div className="product-price-wrapp">
                      <span className="product-price-on-sale">$39.42</span>
                    </div>
                    <div className="product-cart-btn-wrap">
                      <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                    </div>
                  </div>
                </div>
                {/* product-card end */}
              </div>
              {/* product-card-list end */}
              {/* product-card-list start */}
              <div className="product-card-list">
                {/* product-card start */}
                <div className="product-card">
                  <span className="badge bg-success product-badge">new</span>
                  <div className="product-thumb-nail">
                    <a href="single-product.html">
                      <img className="product-image" src="assets/images/products/product-12.jpg" alt="image_not_found" />
                      <img className="product-image-hover-style" src="assets/images/products/product-12.1.jpg" alt="image_not_found" />
                    </a>
                    <ul className="actions">
                      <li className="action whish-list">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist"><i className="lar la-heart" /></button>
                      </li>
                      <li className="action compare">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal-compare" />
                      </li>
                      <li className="action quick-view">
                        <button data-bs-toggle="modal" data-bs-target="#product-modal"><i className="las la-eye" /></button>
                      </li>
                    </ul>
                  </div>
                  <div className="product-content">
                    <h4 className="product-sub-title"><a href="#">Fresh Fruits</a></h4>
                    <h3 className="product-title"><a href="single-product.html">Gilfresh Soup Vegetables</a></h3>
                    <div className="product-price-wrapp">
                      <span className="product-regular-price">$43.80</span>
                      <span className="product-price-on-sale">$39.42</span>
                      <span className="badge bg-danger">-20%</span>
                    </div>
                    <div className="product-cart-btn-wrap">
                      <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">Add to cart</button>
                    </div>
                  </div>
                </div>
                {/* product-card end */}
              </div>
              {/* product-card-list end */}
            </div>
            {/* swiper-slide end*/}

          </Slider>


          {/* swiper navigation */}

          <div className="swiper-button-prev common-swiper-button-prev">
            <i className="las la-angle-left" />
          </div>
          <div className="swiper-button-next common-swiper-button-next">
            <i className="las la-angle-right" />
          </div>



        </div>

      </div>
    </div>
  </div>
</div>
</section>
    </div>

  )
}

export default Fruits


















// import React from 'react'

// function Fruits() {
//   return (
//     <div>
//        <section className="product-carousel">
//         <div className="container position-relative">
//           <div className="row">
//             <div className="section-title">
//               <h2 className="title">Fruits and Vegetables</h2>
//             </div>
//           </div>
//           <div className="row">
//             <div className="col-12">
//               <div className="custom-container">
//                 <div className="custom-col-left">
//                   <aside className="sidebar-widgets">
//                     <div className="widget">
//                       <div className="product-box">
//                         <a href="shop-grid-4-column.html" className="banner-box-animation">
//                           <img src="assets/images/banner/sidebar1.jpg" alt="images_not_found" />
//                         </a>
//                         <ul className="sidebar-menu">
//                           <li className="sidebar-menu-item">
//                             <a className="sidebar-menu-nav-link" href="#">Bananas</a>
//                           </li>
//                           <li className="sidebar-menu-item">
//                             <a className="sidebar-menu-nav-link" href="#">Apples Pears</a>
//                           </li>
//                           <li className="sidebar-menu-item">
//                             <a className="sidebar-menu-nav-link" href="#">Berries Cherries</a>
//                           </li>
//                           <li className="sidebar-menu-item">
//                             <a className="sidebar-menu-nav-link" href="#">Oranges Citrus Fruit</a>
//                           </li>
//                           <li className="sidebar-menu-item">
//                             <a className="sidebar-menu-nav-link" href="#">Onions Leeks</a>
//                           </li>
//                           <li className="sidebar-menu-item">
//                             <a className="sidebar-menu-nav-link" href="#">Carrots Root Vegetables</a>
//                           </li>
//                           <li className="sidebar-menu-item">
//                             <a className="sidebar-menu-nav-link" href="#">Tomatoes</a>
//                           </li>
//                         </ul>
//                       </div>
//                     </div>
//                   </aside>
//                 </div>
//                 <div className="custom-col-right">
//                   <div className="food-carousel-five-items">
//                     <div className="swiper-container">
//                       <div className="swiper-wrapper">
//                         {/* swiper-slide start */}
//                         <div className="product-carousel-item swiper-slide">
//                           {/* product-card-list start */}
//                           <div className="product-card-list">
//                             {/* product-card start */}
//                             <div className="product-card">
//                               <span className="badge bg-success product-badge">new</span>
//                               <div className="product-thumb-nail">
//                                 <a href="single-product.html">
//                                   <img className="product-image" src="assets/images/products/product-1.jpg" alt="image_not_found" />
//                                 </a>
//                                 <ul className="actions">
//                                   <li className="action whish-list">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist">
//                                       <i className="lar la-heart" />
//                                     </button>
//                                   </li>
//                                   <li className="action compare">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal-compare" />
//                                   </li>
//                                   <li className="action quick-view">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal">
//                                       <i className="las la-eye" />
//                                     </button>
//                                   </li>
//                                 </ul>
//                               </div>
//                               <div className="product-content">
//                                 <h4 className="product-sub-title">
//                                   <a href="#">Fresh Vegetables</a>
//                                 </h4>
//                                 <h3 className="product-title">
//                                   <a href="single-product.html">Warburtons 9 Crumpets</a>
//                                 </h3>
//                                 <div className="product-price-wrapp">
//                                   <span className="product-regular-price">$43.80</span>
//                                   <span className="product-price-on-sale">$39.42</span>
//                                   <span className="badge bg-success">-20%</span>
//                                 </div>
//                                 <div className="product-cart-btn-wrap">
//                                   <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">
//                                     Add to cart
//                                   </button>
//                                 </div>
//                               </div>
//                             </div>
//                             {/* product-card end */}
//                           </div>
//                           {/* product-card-list end */}
//                           {/* product-card-list start */}
//                           <div className="product-card-list">
//                             {/* product-card start */}
//                             <div className="product-card">
//                               <span className="badge bg-success product-badge">new</span>
//                               <div className="product-thumb-nail">
//                                 <a href="single-product.html">
//                                   <img className="product-image" src="assets/images/products/product-6.jpg" alt="image_not_found" />
//                                   <img className="product-image-hover-style" src="assets/images/products/product-6.1.jpg" alt="image_not_found" />
//                                 </a>
//                                 <ul className="actions">
//                                   <li className="action whish-list">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist">
//                                       <i className="lar la-heart" />
//                                     </button>
//                                   </li>
//                                   <li className="action compare">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal-compare" />
//                                   </li>
//                                   <li className="action quick-view">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal">
//                                       <i className="las la-eye" />
//                                     </button>
//                                   </li>
//                                 </ul>
//                               </div>
//                               <div className="product-content">
//                                 <h4 className="product-sub-title">
//                                   <a href="#">Fresh Fruits</a>
//                                 </h4>
//                                 <h3 className="product-title">
//                                   <a href="single-product.html">Walkers Meaty Variety Crisps</a>
//                                 </h3>
//                                 <div className="product-price-wrapp">
//                                   <span className="product-regular-price">$43.80</span>
//                                   <span className="product-price-on-sale">$39.42</span>
//                                   <span className="badge bg-danger">-20%</span>
//                                 </div>
//                                 <div className="product-cart-btn-wrap">
//                                   <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">
//                                     Add to cart
//                                   </button>
//                                 </div>
//                               </div>
//                             </div>
//                             {/* product-card end */}
//                           </div>
//                           {/* product-card-list end */}
//                         </div>
//                         {/* swiper-slide end*/}
//                         {/* swiper-slide start */}
//                         <div className="product-carousel-item swiper-slide">
//                           {/* product-card-list start */}
//                           <div className="product-card-list">
//                             {/* product-card start */}
//                             <div className="product-card">
//                               <span className="badge bg-success product-badge">new</span>
//                               <div className="product-thumb-nail">
//                                 <a href="single-product.html">
//                                   <img className="product-image" src="assets/images/products/product-2.jpg" alt="image_not_found" />
//                                   <img className="product-image-hover-style" src="assets/images/products/product-2.1.jpg" alt="image_not_found" />
//                                 </a>
//                                 <ul className="actions">
//                                   <li className="action whish-list">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist">
//                                       <i className="lar la-heart" />
//                                     </button>
//                                   </li>
//                                   <li className="action compare">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal-compare" />
//                                   </li>
//                                   <li className="action quick-view">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal">
//                                       <i className="las la-eye" />
//                                     </button>
//                                   </li>
//                                 </ul>
//                               </div>
//                               <div className="product-content">
//                                 <h4 className="product-sub-title">
//                                   <a href="#">Fresh Fruits</a>
//                                 </h4>
//                                 <h3 className="product-title">
//                                   <a href="single-product.html">Walkers Meaty Variety Crisps</a>
//                                 </h3>
//                                 <div className="product-price-wrapp">
//                                   <span className="product-regular-price">$43.80</span>
//                                   <span className="product-price-on-sale">$39.42</span>
//                                   <span className="badge bg-danger">-20%</span>
//                                 </div>
//                                 <div className="product-cart-btn-wrap">
//                                   <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">
//                                     Add to cart
//                                   </button>
//                                 </div>
//                               </div>
//                             </div>
//                             {/* product-card end */}
//                           </div>
//                           {/* product-card-list end */}
//                           {/* product-card-list start */}
//                           <div className="product-card-list">
//                             {/* product-card start */}
//                             <div className="product-card">
//                               <span className="badge bg-success product-badge">new</span>
//                               <div className="product-thumb-nail">
//                                 <a href="single-product.html">
//                                   <img className="product-image" src="assets/images/products/product-7.jpg" alt="image_not_found" />
//                                   <img className="product-image-hover-style" src="assets/images/products/product-7.1.jpg" alt="image_not_found" />
//                                 </a>
//                                 <ul className="actions">
//                                   <li className="action whish-list">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist">
//                                       <i className="lar la-heart" />
//                                     </button>
//                                   </li>
//                                   <li className="action compare">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal-compare" />
//                                   </li>
//                                   <li className="action quick-view">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal">
//                                       <i className="las la-eye" />
//                                     </button>
//                                   </li>
//                                 </ul>
//                               </div>
//                               <div className="product-content">
//                                 <h4 className="product-sub-title">
//                                   <a href="#">Fresh Fruits</a>
//                                 </h4>
//                                 <h3 className="product-title">
//                                   <a href="single-product.html">Snacking Essentials Walnuts</a>
//                                 </h3>
//                                 <div className="product-price-wrapp">
//                                   <span className="product-price-on-sale">$39.42</span>
//                                 </div>
//                                 <div className="product-cart-btn-wrap">
//                                   <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">
//                                     Add to cart
//                                   </button>
//                                 </div>
//                               </div>
//                             </div>
//                             {/* product-card end */}
//                           </div>
//                           {/* product-card-list end */}
//                         </div>
//                         {/* swiper-slide end*/}
//                         {/* swiper-slide start */}
//                         <div className="product-carousel-item swiper-slide">
//                           {/* product-card-list start */}
//                           <div className="product-card-list">
//                             {/* product-card start */}
//                             <div className="product-card">
//                               <span className="badge bg-success product-badge">new</span>
//                               <div className="product-thumb-nail">
//                                 <a href="single-product.html">
//                                   <img className="product-image" src="assets/images/products/product-3.jpg" alt="image_not_found" />
//                                 </a>
//                                 <ul className="actions">
//                                   <li className="action whish-list">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist">
//                                       <i className="lar la-heart" />
//                                     </button>
//                                   </li>
//                                   <li className="action compare">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal-compare" />
//                                   </li>
//                                   <li className="action quick-view">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal">
//                                       <i className="las la-eye" />
//                                     </button>
//                                   </li>
//                                 </ul>
//                               </div>
//                               <div className="product-content">
//                                 <h4 className="product-sub-title">
//                                   <a href="#">Fresh Vegetables</a>
//                                 </h4>
//                                 <h3 className="product-title">
//                                   <a href="single-product.html">Snacking Essentials Cashew</a>
//                                 </h3>
//                                 <div className="product-price-wrapp">
//                                   <span className="product-regular-price">$43.80</span>
//                                   <span className="product-price-on-sale">$39.42</span>
//                                   <span className="badge bg-success">-20%</span>
//                                 </div>
//                                 <div className="product-cart-btn-wrap">
//                                   <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">
//                                     Add to cart
//                                   </button>
//                                 </div>
//                               </div>
//                             </div>
//                             {/* product-card end */}
//                           </div>
//                           {/* product-card-list end */}
//                           {/* product-card-list start */}
//                           <div className="product-card-list">
//                             {/* product-card start */}
//                             <div className="product-card">
//                               <span className="badge bg-success product-badge">new</span>
//                               <div className="product-thumb-nail">
//                                 <a href="single-product.html">
//                                   <img className="product-image" src="assets/images/products/product-8.jpg" alt="image_not_found" />
//                                   <img className="product-image-hover-style" src="assets/images/products/product-8.1.jpg" alt="image_not_found" />
//                                 </a>
//                                 <ul className="actions">
//                                   <li className="action whish-list">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist">
//                                       <i className="lar la-heart" />
//                                     </button>
//                                   </li>
//                                   <li className="action compare">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal-compare" />
//                                   </li>
//                                   <li className="action quick-view">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal">
//                                       <i className="las la-eye" />
//                                     </button>
//                                   </li>
//                                 </ul>
//                               </div>
//                               <div className="product-content">
//                                 <h4 className="product-sub-title">
//                                   <a href="#">Fresh Fruits</a>
//                                 </h4>
//                                 <h3 className="product-title">
//                                   <a href="single-product.html">Skips Prawn Cocktail Flavour</a>
//                                 </h3>
//                                 <div className="product-price-wrapp">
//                                   <span className="product-price-on-sale">$39.42</span>
//                                 </div>
//                                 <div className="product-cart-btn-wrap">
//                                   <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">
//                                     Add to cart
//                                   </button>
//                                 </div>
//                               </div>
//                             </div>
//                             {/* product-card end */}
//                           </div>
//                           {/* product-card-list end */}
//                         </div>
//                         {/* swiper-slide end*/}
//                         {/* swiper-slide start */}
//                         <div className="product-carousel-item swiper-slide">
//                           {/* product-card-list start */}
//                           <div className="product-card-list">
//                             {/* product-card start */}
//                             <div className="product-card">
//                               <span className="badge bg-success product-badge">new</span>
//                               <div className="product-thumb-nail">
//                                 <a href="single-product.html">
//                                   <img className="product-image" src="assets/images/products/product-4.jpg" alt="image_not_found" />
//                                   <img className="product-image-hover-style" src="assets/images/products/product-4.1.jpg" alt="image_not_found" />
//                                 </a>
//                                 <ul className="actions">
//                                   <li className="action whish-list">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist">
//                                       <i className="lar la-heart" />
//                                     </button>
//                                   </li>
//                                   <li className="action compare">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal-compare" />
//                                   </li>
//                                   <li className="action quick-view">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal">
//                                       <i className="las la-eye" />
//                                     </button>
//                                   </li>
//                                 </ul>
//                               </div>
//                               <div className="product-content">
//                                 <h4 className="product-sub-title">
//                                   <a href="#">Fresh Vegetables</a>
//                                 </h4>
//                                 <h3 className="product-title">
//                                   <a href="single-product.html">Salad Selection Pack</a>
//                                 </h3>
//                                 <div className="product-price-wrapp">
//                                   <span className="product-regular-price">$43.80</span>
//                                   <span className="product-price-on-sale">$39.42</span>
//                                   <span className="badge bg-success">-20%</span>
//                                 </div>
//                                 <div className="product-cart-btn-wrap">
//                                   <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">
//                                     Add to cart
//                                   </button>
//                                 </div>
//                               </div>
//                             </div>
//                             {/* product-card end */}
//                           </div>
//                           {/* product-card-list end */}
//                           {/* product-card-list start */}
//                           <div className="product-card-list">
//                             {/* product-card start */}
//                             <div className="product-card">
//                               <span className="badge bg-success product-badge">new</span>
//                               <div className="product-thumb-nail">
//                                 <a href="single-product.html">
//                                   <img className="product-image" src="assets/images/products/product-9.jpg" alt="image_not_found" />
//                                   <img className="product-image-hover-style" src="assets/images/products/product-9.1.jpg" alt="image_not_found" />
//                                 </a>
//                                 <ul className="actions">
//                                   <li className="action whish-list">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist">
//                                       <i className="lar la-heart" />
//                                     </button>
//                                   </li>
//                                   <li className="action compare">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal-compare" />
//                                   </li>
//                                   <li className="action quick-view">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal">
//                                       <i className="las la-eye" />
//                                     </button>
//                                   </li>
//                                 </ul>
//                               </div>
//                               <div className="product-content">
//                                 <h4 className="product-sub-title">
//                                   <a href="#">Fresh Fruits</a>
//                                 </h4>
//                                 <h3 className="product-title">
//                                   <a href="single-product.html">Red Seedless Grapes</a>
//                                 </h3>
//                                 <div className="product-price-wrapp">
//                                   <span className="product-regular-price">$43.80</span>
//                                   <span className="product-price-on-sale">$39.42</span>
//                                 </div>
//                                 <div className="product-cart-btn-wrap">
//                                   <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">
//                                     Add to cart
//                                   </button>
//                                 </div>
//                               </div>
//                             </div>
//                             {/* product-card end */}
//                           </div>
//                           {/* product-card-list end */}
//                         </div>
//                         {/* swiper-slide end*/}
//                         {/* swiper-slide start */}
//                         <div className="product-carousel-item swiper-slide">
//                           {/* product-card-list start */}
//                           <div className="product-card-list">
//                             {/* product-card start */}
//                             <div className="product-card">
//                               <span className="badge bg-success product-badge">new</span>
//                               <div className="product-thumb-nail">
//                                 <a href="single-product.html">
//                                   <img className="product-image" src="assets/images/products/product-5.jpg" alt="image_not_found" />
//                                   <img className="product-image-hover-style" src="assets/images/products/product-5.1.jpg" alt="image_not_found" />
//                                 </a>
//                                 <ul className="actions">
//                                   <li className="action whish-list">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist">
//                                       <i className="lar la-heart" />
//                                     </button>
//                                   </li>
//                                   <li className="action compare">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal-compare" />
//                                   </li>
//                                   <li className="action quick-view">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal">
//                                       <i className="las la-eye" />
//                                     </button>
//                                   </li>
//                                 </ul>
//                               </div>
//                               <div className="product-content">
//                                 <h4 className="product-sub-title">
//                                   <a href="#">Fresh Vegetables</a>
//                                 </h4>
//                                 <h3 className="product-title">
//                                   <a href="single-product.html">Pink Lady Apples 4 Pack</a>
//                                 </h3>
//                                 <div className="product-price-wrapp">
//                                   <span className="product-regular-price">$43.80</span>
//                                   <span className="product-price-on-sale">$39.42</span>
//                                   <span className="badge bg-success">-20%</span>
//                                 </div>
//                                 <div className="product-cart-btn-wrap">
//                                   <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">
//                                     Add to cart
//                                   </button>
//                                 </div>
//                               </div>
//                             </div>
//                             {/* product-card end */}
//                           </div>
//                           {/* product-card-list end */}
//                           {/* product-card-list start */}
//                           <div className="product-card-list">
//                             {/* product-card start */}
//                             <div className="product-card">
//                               <span className="badge bg-success product-badge">new</span>
//                               <div className="product-thumb-nail">
//                                 <a href="single-product.html">
//                                   <img className="product-image" src="assets/images/products/product-10.jpg" alt="image_not_found" />
//                                 </a>
//                                 <ul className="actions">
//                                   <li className="action whish-list">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist">
//                                       <i className="lar la-heart" />
//                                     </button>
//                                   </li>
//                                   <li className="action compare">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal-compare" />
//                                   </li>
//                                   <li className="action quick-view">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal">
//                                       <i className="las la-eye" />
//                                     </button>
//                                   </li>
//                                 </ul>
//                               </div>
//                               <div className="product-content">
//                                 <h4 className="product-sub-title">
//                                   <a href="#">Fresh Fruits</a>
//                                 </h4>
//                                 <h3 className="product-title">
//                                   <a href="single-product.html">Mini Corn Cobs 625g</a>
//                                 </h3>
//                                 <div className="product-price-wrapp">
//                                   <span className="product-price-on-sale">$39.42</span>
//                                 </div>
//                                 <div className="product-cart-btn-wrap">
//                                   <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">
//                                     Add to cart
//                                   </button>
//                                 </div>
//                               </div>
//                             </div>
//                             {/* product-card end */}
//                           </div>
//                           {/* product-card-list end */}
//                         </div>
//                         {/* swiper-slide end*/}
//                         {/* swiper-slide start */}
//                         <div className="product-carousel-item swiper-slide">
//                           {/* product-card-list start */}
//                           <div className="product-card-list">
//                             {/* product-card start */}
//                             <div className="product-card">
//                               <span className="badge bg-success product-badge">new</span>
//                               <div className="product-thumb-nail">
//                                 <a href="single-product.html">
//                                   <img className="product-image" src="assets/images/products/product-11.jpg" alt="image_not_found" />
//                                   <img className="product-image-hover-style" src="assets/images/products/product-11.1.jpg" alt="image_not_found" />
//                                 </a>
//                                 <ul className="actions">
//                                   <li className="action whish-list">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist">
//                                       <i className="lar la-heart" />
//                                     </button>
//                                   </li>
//                                   <li className="action compare">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal-compare" />
//                                   </li>
//                                   <li className="action quick-view">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal">
//                                       <i className="las la-eye" />
//                                     </button>
//                                   </li>
//                                 </ul>
//                               </div>
//                               <div className="product-content">
//                                 <h4 className="product-sub-title">
//                                   <a href="#">Fresh Vegetables</a>
//                                 </h4>
//                                 <h3 className="product-title">
//                                   <a href="single-product.html">lorette Sweet &amp; Crunchy</a>
//                                 </h3>
//                                 <div className="product-price-wrapp">
//                                   <span className="product-price-on-sale">$39.42</span>
//                                 </div>
//                                 <div className="product-cart-btn-wrap">
//                                   <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">
//                                     Add to cart
//                                   </button>
//                                 </div>
//                               </div>
//                             </div>
//                             {/* product-card end */}
//                           </div>
//                           {/* product-card-list end */}
//                           {/* product-card-list start */}
//                           <div className="product-card-list">
//                             {/* product-card start */}
//                             <div className="product-card">
//                               <span className="badge bg-success product-badge">new</span>
//                               <div className="product-thumb-nail">
//                                 <a href="single-product.html">
//                                   <img className="product-image" src="assets/images/products/product-12.jpg" alt="image_not_found" />
//                                   <img className="product-image-hover-style" src="assets/images/products/product-12.1.jpg" alt="image_not_found" />
//                                 </a>
//                                 <ul className="actions">
//                                   <li className="action whish-list">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal-wishlist">
//                                       <i className="lar la-heart" />
//                                     </button>
//                                   </li>
//                                   <li className="action compare">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal-compare" />
//                                   </li>
//                                   <li className="action quick-view">
//                                     <button data-bs-toggle="modal" data-bs-target="#product-modal">
//                                       <i className="las la-eye" />
//                                     </button>
//                                   </li>
//                                 </ul>
//                               </div>
//                               <div className="product-content">
//                                 <h4 className="product-sub-title">
//                                   <a href="#">Fresh Fruits</a>
//                                 </h4>
//                                 <h3 className="product-title">
//                                   <a href="single-product.html">Gilfresh Soup Vegetables</a>
//                                 </h3>
//                                 <div className="product-price-wrapp">
//                                   <span className="product-regular-price">$43.80</span>
//                                   <span className="product-price-on-sale">$39.42</span>
//                                   <span className="badge bg-danger">-20%</span>
//                                 </div>
//                                 <div className="product-cart-btn-wrap">
//                                   <button data-bs-toggle="modal" data-bs-target="#addto-cart-modal" className="btn btn-dark add-to-cart-btn">
//                                     Add to cart
//                                   </button>
//                                 </div>
//                               </div>
//                             </div>
//                             {/* product-card end */}
//                           </div>
//                           {/* product-card-list end */}
//                         </div>
//                         {/* swiper-slide end*/}
//                       </div>
//                     </div>
//                     {/* swiper navigation */}
//                     <div className="swiper-button-prev common-swiper-button-prev">
//                       <i className="las la-angle-left" />
//                     </div>
//                     <div className="swiper-button-next common-swiper-button-next">
//                       <i className="las la-angle-right" />
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </section> 
//     </div>
//   )
// }

// export default Fruits
