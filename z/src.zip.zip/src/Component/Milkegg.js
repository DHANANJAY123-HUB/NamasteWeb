import React from 'react'
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";


function Milkegg() {
  var setting3 = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1
  };


  return (
    <div>
      <section className="categories-section section-mb">
<div className="container">
  <div className="row">
    <div className="col-xl-9">
      <div className="row mb-n7">

        <div className="col-lg-4 mb-7">
          <div className="section-title categories">
            <h2 className="title">Milk</h2>
          </div>

          <div className="categories-carousel">
            <div className="swiper-container">
              <div className="swiper-wrapper">
                {/* swiper-slide start */}
                <div className="categories-carousel-item swiper-slide">

                  {/* categories card-list start */}

                  <Slider {...setting3}>
                    <div>
                      <div className="categories-card-list">
                        {/* categories-card start */}
                        <div className="categories-card">
                          <div className="categories-thumb-nail">
                            <a href="single-product.html">
                              <img className="categories-image" src="assets/images/products/product-8.jpg" alt="image_not_found" />
                              <img className="categories-image-hover-style" src="assets/images/products/product-8.1.jpg" alt="image_not_found" />
                            </a>
                            <div className="quick-view-btn-wrap">
                              <button className="quick-view-btn" data-bs-toggle="modal" data-bs-target="#product-modal">
                                <i className="las la-eye" />
                              </button>
                            </div>
                          </div>
                          <div className="categories-content">
                            <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                            <h3 className="product-title"><a href="single-product.html">Skips Prawn Cocktail Flavour</a></h3>
                            <div className="product-price-wrapp">
                              <span className="product-regular-price">$43.80</span>
                              <span className="product-price-on-sale">$39.42</span>
                            </div>
                          </div>
                        </div>
                        {/* categories-card end */}
                      </div>
                      {/* categories  card-list end */}
                      {/* categories card-list start */}
                      <div className="categories-card-list">
                        {/* categories-card start */}
                        <div className="categories-card">
                          <div className="categories-thumb-nail">
                            <a href="single-product.html">
                              <img className="categories-image" src="assets/images/products/product-7.jpg" alt="image_not_found" />
                              <img className="categories-image-hover-style" src="assets/images/products/product-7.1.jpg" alt="image_not_found" />
                            </a>
                            <div className="quick-view-btn-wrap">
                              <button className="quick-view-btn" data-bs-toggle="modal" data-bs-target="#product-modal">
                                <i className="las la-eye" />
                              </button>
                            </div>
                          </div>
                          <div className="categories-content">
                            <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                            <h3 className="product-title"><a href="single-product.html">Snacking Essentials Walnuts</a></h3>
                            <div className="product-price-wrapp">
                              <span className="product-regular-price">$43.80</span>
                              <span className="product-price-on-sale">$39.42</span>
                            </div>
                          </div>
                        </div>
                        {/* categories-card end */}
                      </div>
                      {/* categories card-list end */}
                      {/* categories card-list start */}
                      <div className="categories-card-list">
                        {/* categories-card start */}
                        <div className="categories-card">
                          <div className="categories-thumb-nail">
                            <a href="single-product.html">
                              <img className="categories-image" src="assets/images/products/product-5.jpg" alt="image_not_found" />
                              <img className="categories-image-hover-style" src="assets/images/products/product-5.1.jpg" alt="image_not_found" />
                            </a>
                            <div className="quick-view-btn-wrap">
                              <button className="quick-view-btn" data-bs-toggle="modal" data-bs-target="#product-modal">
                                <i className="las la-eye" />
                              </button>
                            </div>
                          </div>
                          <div className="categories-content">
                            <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                            <h3 className="product-title"><a href="single-product.html">Pink Lady Apples 4 Pack</a></h3>
                            <div className="product-price-wrapp">
                              <span className="product-regular-price">$43.80</span>
                              <span className="product-price-on-sale">$39.42</span>
                            </div>
                          </div>
                        </div>
                        {/* categories-card end */}
                      </div>
                    </div>
                    <div>
                      <div className="categories-card-list">
                        {/* categories-card start */}
                        <div className="categories-card">
                          <div className="categories-thumb-nail">
                            <a href="single-product.html">
                              <img className="categories-image" src="assets/images/products/product-3.jpg" alt="image_not_found" />
                            </a>
                            <div className="quick-view-btn-wrap">
                              <button className="quick-view-btn" data-bs-toggle="modal" data-bs-target="#product-modal">
                                <i className="las la-eye" />
                              </button>
                            </div>
                          </div>
                          <div className="categories-content">
                            <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                            <h3 className="product-title"><a href="single-product.html">Snacking Essentials Cashew</a></h3>
                            <div className="product-price-wrapp">
                              <span className="product-regular-price">$43.80</span>
                              <span className="product-price-on-sale">$39.42</span>
                            </div>
                          </div>
                        </div>
                        {/* categories-card end */}
                      </div>
                      {/* categories card-list end */}
                      {/* categories card-list start */}
                      <div className="categories-card-list">
                        {/* categories-card start */}
                        <div className="categories-card">
                          <div className="categories-thumb-nail">
                            <a href="single-product.html">
                              <img className="categories-image" src="assets/images/products/product-2.jpg" alt="image_not_found" />
                              <img className="categories-image-hover-style" src="assets/images/products/product-2.1.jpg" alt="image_not_found" />
                            </a>
                            <div className="quick-view-btn-wrap">
                              <button className="quick-view-btn" data-bs-toggle="modal" data-bs-target="#product-modal">
                                <i className="las la-eye" />
                              </button>
                            </div>
                          </div>
                          <div className="categories-content">
                            <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                            <h3 className="product-title"><a href="single-product.html">Apple &amp; Raspberry Juice Drink</a></h3>
                            <div className="product-price-wrapp">
                              <span className="product-regular-price">$43.80</span>
                              <span className="product-price-on-sale">$39.42</span>
                            </div>
                          </div>
                        </div>
                        {/* categories-card end */}
                      </div>
                      {/* categories card-list end */}
                      {/* categories card-list start */}
                      <div className="categories-card-list">
                        {/* categories-card start */}
                        <div className="categories-card">
                          <div className="categories-thumb-nail">
                            <a href="single-product.html">
                              <img className="categories-image" src="assets/images/products/product-5.jpg" alt="image_not_found" />
                              <img className="categories-image-hover-style" src="assets/images/products/product-5.1.jpg" alt="image_not_found" />
                            </a>
                            <div className="quick-view-btn-wrap">
                              <button className="quick-view-btn" data-bs-toggle="modal" data-bs-target="#product-modal">
                                <i className="las la-eye" />
                              </button>
                            </div>
                          </div>
                          <div className="categories-content">
                            <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                            <h3 className="product-title"><a href="single-product.html">Pink Lady Apples 4 Pack</a></h3>
                            <div className="product-price-wrapp">
                              <span className="product-regular-price">$43.80</span>
                              <span className="product-price-on-sale">$39.42</span>
                            </div>
                          </div>
                        </div>
                        {/* categories-card end */}
                      </div>
                    </div>
                  </Slider>
                </div>

              </div>
            </div>
            {/* swiper navigation */}
            <div class="swiper-button-prev common-swiper-button-prev">
              <i class="las la-angle-left"></i>
            </div>
            <div class="swiper-button-next common-swiper-button-next">
              <i class="las la-angle-right"></i>
            </div>

          </div>
        </div>


        <div className="col-lg-4 mb-7">
          <div className="section-title categories">
            <h2 className="title">Eggs</h2>
          </div>
          <div className="categories-carousel2">
            <div className="swiper-container">
              <div className="swiper-wrapper">
                {/* swiper-slide start */}
                <div className="categories-carousel-item swiper-slide">
                  {/* categories card-list start */}

                  <Slider {...setting3}>
                    <div>
                      <div className="categories-card-list">
                        {/* categories-card start */}
                        <div className="categories-card">
                          <div className="categories-thumb-nail">
                            <a href="single-product.html">
                              <img className="categories-image" src="assets/images/products/product-3.jpg" alt="image_not_found" />
                            </a>
                            <div className="quick-view-btn-wrap">
                              <button className="quick-view-btn" data-bs-toggle="modal" data-bs-target="#product-modal">
                                <i className="las la-eye" />
                              </button>
                            </div>
                          </div>
                          <div className="categories-content">
                            <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                            <h3 className="product-title"><a href="single-product.html">Snacking Essentials Cashew</a></h3>
                            <div className="product-price-wrapp">
                              <span className="product-regular-price">$43.80</span>
                              <span className="product-price-on-sale">$39.42</span>
                            </div>
                          </div>
                        </div>
                        {/* categories-card end */}
                      </div>
                      {/* categories card-list end */}
                      {/* categories card-list start */}
                      <div className="categories-card-list">
                        {/* categories-card start */}
                        <div className="categories-card">
                          <div className="categories-thumb-nail">
                            <a href="single-product.html">
                              <img className="categories-image" src="assets/images/products/product-2.jpg" alt="image_not_found" />
                              <img className="categories-image-hover-style" src="assets/images/products/product-2.1.jpg" alt="image_not_found" />
                            </a>
                            <div className="quick-view-btn-wrap">
                              <button className="quick-view-btn" data-bs-toggle="modal" data-bs-target="#product-modal">
                                <i className="las la-eye" />
                              </button>
                            </div>
                          </div>
                          <div className="categories-content">
                            <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                            <h3 className="product-title"><a href="single-product.html">Apple &amp; Raspberry Juice Drink</a></h3>
                            <div className="product-price-wrapp">
                              <span className="product-regular-price">$43.80</span>
                              <span className="product-price-on-sale">$39.42</span>
                            </div>
                          </div>
                        </div>
                        {/* categories-card end */}
                      </div>
                      {/* categories card-list end */}
                      {/* categories card-list start */}
                      <div className="categories-card-list">
                        {/* categories-card start */}
                        <div className="categories-card">
                          <div className="categories-thumb-nail">
                            <a href="single-product.html">
                              <img className="categories-image" src="assets/images/products/product-5.jpg" alt="image_not_found" />
                              <img className="categories-image-hover-style" src="assets/images/products/product-5.1.jpg" alt="image_not_found" />
                            </a>
                            <div className="quick-view-btn-wrap">
                              <button className="quick-view-btn" data-bs-toggle="modal" data-bs-target="#product-modal">
                                <i className="las la-eye" />
                              </button>
                            </div>
                          </div>
                          <div className="categories-content">
                            <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                            <h3 className="product-title"><a href="single-product.html">Pink Lady Apples 4 Pack</a></h3>
                            <div className="product-price-wrapp">
                              <span className="product-regular-price">$43.80</span>
                              <span className="product-price-on-sale">$39.42</span>
                            </div>
                          </div>
                        </div>
                        {/* categories-card end */}
                      </div>
                    </div>

                    <div>
                      <div className="categories-card-list">
                        {/* categories-card start */}
                        <div className="categories-card">
                          <div className="categories-thumb-nail">
                            <a href="single-product.html">
                              <img className="categories-image" src="assets/images/products/product-8.jpg" alt="image_not_found" />
                              <img className="categories-image-hover-style" src="assets/images/products/product-8.1.jpg" alt="image_not_found" />
                            </a>
                            <div className="quick-view-btn-wrap">
                              <button className="quick-view-btn" data-bs-toggle="modal" data-bs-target="#product-modal">
                                <i className="las la-eye" />
                              </button>
                            </div>
                          </div>
                          <div className="categories-content">
                            <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                            <h3 className="product-title"><a href="single-product.html">Skips Prawn Cocktail Flavour</a></h3>
                            <div className="product-price-wrapp">
                              <span className="product-regular-price">$43.80</span>
                              <span className="product-price-on-sale">$39.42</span>
                            </div>
                          </div>
                        </div>
                        {/* categories-card end */}
                      </div>
                      {/* categories card-list end */}
                      {/* categories card-list start */}
                      <div className="categories-card-list">
                        {/* categories-card start */}
                        <div className="categories-card">
                          <div className="categories-thumb-nail">
                            <a href="single-product.html">
                              <img className="categories-image" src="assets/images/products/product-5.jpg" alt="image_not_found" />
                              <img className="categories-image-hover-style" src="assets/images/products/product-5.1.jpg" alt="image_not_found" />
                            </a>
                            <div className="quick-view-btn-wrap">
                              <button className="quick-view-btn" data-bs-toggle="modal" data-bs-target="#product-modal">
                                <i className="las la-eye" />
                              </button>
                            </div>
                          </div>
                          <div className="categories-content">
                            <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                            <h3 className="product-title"><a href="single-product.html">Pink Lady Apples 4 Pack</a></h3>
                            <div className="product-price-wrapp">
                              <span className="product-regular-price">$43.80</span>
                              <span className="product-price-on-sale">$39.42</span>
                            </div>
                          </div>
                        </div>
                        {/* categories-card end */}
                      </div>
                      {/* categories card-list end */}
                      {/* categories card-list start */}
                      <div className="categories-card-list">
                        {/* categories-card start */}
                        <div className="categories-card">
                          <div className="categories-thumb-nail">
                            <a href="single-product.html">
                              <img className="categories-image" src="assets/images/products/product-7.jpg" alt="image_not_found" />
                              <img className="categories-image-hover-style" src="assets/images/products/product-7.1.jpg" alt="image_not_found" />
                            </a>
                            <div className="quick-view-btn-wrap">
                              <button className="quick-view-btn" data-bs-toggle="modal" data-bs-target="#product-modal">
                                <i className="las la-eye" />
                              </button>
                            </div>
                          </div>
                          <div className="categories-content">
                            <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                            <h3 className="product-title"><a href="single-product.html">Snacking Essentials Walnuts</a></h3>
                            <div className="product-price-wrapp">
                              <span className="product-regular-price">$43.80</span>
                              <span className="product-price-on-sale">$39.42</span>
                            </div>
                          </div>
                        </div>
                        {/* categories-card end */}
                      </div>
                    </div>
                  </Slider>
                  {/* categories card-list end */}
                </div>

              </div>
            </div>
            {/* swiper navigation */}
            <div className="swiper-button-prev common-swiper-button-prev">
              <i className="las la-angle-left" />
            </div>
            <div className="swiper-button-next common-swiper-button-next">
              <i className="las la-angle-right" />
            </div>
          </div>
        </div>
        <div className="col-lg-4 mb-7">
          <div className="section-title categories">
            <h2 className="title">Baking &amp; Cooking</h2>
          </div>
          <div className="categories-carousel3">
            <div className="swiper-container">
              <div className="swiper-wrapper">
                {/* swiper-slide start */}
                <div className="categories-carousel-item swiper-slide">
                  {/* categories card-list start */}

                  <Slider {...setting3}>
                    <div>

                      <div className="categories-card-list">
                        {/* categories-card start */}
                        <div className="categories-card">
                          <div className="categories-thumb-nail">
                            <a href="single-product.html">
                              <img className="categories-image" src="assets/images/products/product-13.jpg" alt="image_not_found" />
                              <img className="categories-image-hover-style" src="assets/images/products/product-13.1.jpg" alt="image_not_found" />
                            </a>
                            <div className="quick-view-btn-wrap">
                              <button className="quick-view-btn" data-bs-toggle="modal" data-bs-target="#product-modal">
                                <i className="las la-eye" />
                              </button>
                            </div>
                          </div>
                          <div className="categories-content">
                            <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                            <h3 className="product-title"><a href="single-product.html">Cranberry Juice Drink</a></h3>
                            <div className="product-price-wrapp">
                              <span className="product-regular-price">$43.80</span>
                              <span className="product-price-on-sale">$39.42</span>
                            </div>
                          </div>
                        </div>
                        {/* categories-card end */}
                      </div>
                      {/* categories card-list end */}
                      {/* categories card-list start */}
                      <div className="categories-card-list">
                        {/* categories-card start */}
                        <div className="categories-card">
                          <div className="categories-thumb-nail">
                            <a href="single-product.html">
                              <img className="categories-image" src="assets/images/products/product-9.jpg" alt="image_not_found" />
                              <img className="categories-image-hover-style" src="assets/images/products/product-9.1.jpg" alt="image_not_found" />
                            </a>
                            <div className="quick-view-btn-wrap">
                              <button className="quick-view-btn" data-bs-toggle="modal" data-bs-target="#product-modal">
                                <i className="las la-eye" />
                              </button>
                            </div>
                          </div>
                          <div className="categories-content">
                            <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                            <h3 className="product-title"><a href="single-product.html">Red Seedless Grapes</a></h3>
                            <div className="product-price-wrapp">
                              <span className="product-regular-price">$43.80</span>
                              <span className="product-price-on-sale">$39.42</span>
                            </div>
                          </div>
                        </div>
                        {/* categories-card end */}
                      </div>
                      {/* categories card-list end */}
                      {/* categories card-list start */}
                      <div className="categories-card-list">
                        {/* categories-card start */}
                        <div className="categories-card">
                          <div className="categories-thumb-nail">
                            <a href="single-product.html">
                              <img className="categories-image" src="assets/images/products/product-5.jpg" alt="image_not_found" />
                              <img className="categories-image-hover-style" src="assets/images/products/product-5.1.jpg" alt="image_not_found" />
                            </a>
                            <div className="quick-view-btn-wrap">
                              <button className="quick-view-btn" data-bs-toggle="modal" data-bs-target="#product-modal">
                                <i className="las la-eye" />
                              </button>
                            </div>
                          </div>
                          <div className="categories-content">
                            <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                            <h3 className="product-title"><a href="single-product.html">Pink Lady Apples 4 Pack</a></h3>
                            <div className="product-price-wrapp">
                              <span className="product-regular-price">$43.80</span>
                              <span className="product-price-on-sale">$39.42</span>
                            </div>
                          </div>
                        </div>
                        {/* categories-card end */}
                      </div>
                    </div>
                    <div>
                      <div className="categories-card-list">
                        {/* categories-card start */}
                        <div className="categories-card">
                          <div className="categories-thumb-nail">
                            <a href="single-product.html">
                              <img className="categories-image" src="assets/images/products/product-3.jpg" alt="image_not_found" />
                            </a>
                            <div className="quick-view-btn-wrap">
                              <button className="quick-view-btn" data-bs-toggle="modal" data-bs-target="#product-modal">
                                <i className="las la-eye" />
                              </button>
                            </div>
                          </div>
                          <div className="categories-content">
                            <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                            <h3 className="product-title"><a href="single-product.html">Snacking Essentials Cashew</a></h3>
                            <div className="product-price-wrapp">
                              <span className="product-regular-price">$43.80</span>
                              <span className="product-price-on-sale">$39.42</span>
                            </div>
                          </div>
                        </div>
                        {/* categories-card end */}
                      </div>
                      {/* categories card-list end */}
                      {/* categories card-list start */}
                      <div className="categories-card-list">
                        {/* categories-card start */}
                        <div className="categories-card">
                          <div className="categories-thumb-nail">
                            <a href="single-product.html">
                              <img className="categories-image" src="assets/images/products/product-2.jpg" alt="image_not_found" />
                              <img className="categories-image-hover-style" src="assets/images/products/product-2.1.jpg" alt="image_not_found" />
                            </a>
                            <div className="quick-view-btn-wrap">
                              <button className="quick-view-btn" data-bs-toggle="modal" data-bs-target="#product-modal">
                                <i className="las la-eye" />
                              </button>
                            </div>
                          </div>
                          <div className="categories-content">
                            <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                            <h3 className="product-title"><a href="single-product.html">Apple &amp; Raspberry Juice Drink</a></h3>
                            <div className="product-price-wrapp">
                              <span className="product-regular-price">$43.80</span>
                              <span className="product-price-on-sale">$39.42</span>
                            </div>
                          </div>
                        </div>
                        {/* categories-card end */}
                      </div>
                      {/* categories card-list end */}
                      {/* categories card-list start */}
                      <div className="categories-card-list">
                        {/* categories-card start */}
                        <div className="categories-card">
                          <div className="categories-thumb-nail">
                            <a href="single-product.html">
                              <img className="categories-image" src="assets/images/products/product-5.jpg" alt="image_not_found" />
                              <img className="categories-image-hover-style" src="assets/images/products/product-5.1.jpg" alt="image_not_found" />
                            </a>
                            <div className="quick-view-btn-wrap">
                              <button className="quick-view-btn" data-bs-toggle="modal" data-bs-target="#product-modal">
                                <i className="las la-eye" />
                              </button>
                            </div>
                          </div>
                          <div className="categories-content">
                            <h4 className="product-sub-title"><a href="#">Fresh Vegetables</a></h4>
                            <h3 className="product-title"><a href="single-product.html">Pink Lady Apples 4 Pack</a></h3>
                            <div className="product-price-wrapp">
                              <span className="product-regular-price">$43.80</span>
                              <span className="product-price-on-sale">$39.42</span>
                            </div>
                          </div>
                        </div>
                        {/* categories-card end */}
                      </div>
                    </div>
                  </Slider>
                  {/* categories card-list end */}
                </div>

              </div>
            </div>
            {/* swiper navigation */}
            <div className="swiper-button-prev common-swiper-button-prev">
              <i className="las la-angle-left" />
            </div>
            <div className="swiper-button-next common-swiper-button-next">
              <i className="las la-angle-right" />
            </div>
          </div>
        </div>
      </div>
    </div>
    <div className="col-xl-3 d-none d-xl-block">
      <a href="shop-grid-4-column.html" className="banner-box-animation">
        <img src="assets/images/banner/sidebar2.jpg" alt="images_not_found" /></a>
    </div>



  </div>

</div>
</section>

{/* categories section end */}
{/* news letter section start */}
{/* <section className="news-letter-sectoin bg-success">
<div className="container">
  <div className="row align-items-center">
    <div className="col-lg-8 col-xl-9">
      <div className="news-letter-wrap">
        <div className="news-letter-title">
          <h3 className="title">DOWNLOAD OUR APP</h3>
          <p>Download now to get more offers.</p>
        </div>
       
      </div>
    </div>
    <div className="col-lg-4 col-xl-3">
      <div className="text-center text-lg-end mt-7 mt-lg-0">
        <a className="store-btn" href="#">
          <img src="assets/images/icon/app_store.png" alt="images_not_found" />
        </a>
        <a className="store-btn" href="#">
          <img src="assets/images/icon/google_play.png" alt="images_not_found" />
        </a>
      </div>
    </div>
  </div>
</div>
</section> */}
{/* news letter section end */}
{/* service section start */}
{/* <section className="service-section section-mt section-mb">
<div className="container">
  <div className="services">
    <div className="row mb-n7">
      <div className="col-sm-6 col-lg-3 mb-7">
        <div className="service-item">
          <img className="service-icon" src="assets/images/icon/service1.png" alt="images_not_found" />
          <h3 className="service-title">100% SECURE PAYMENTS</h3>
          <p>Moving your card details to a much more secured place</p>
        </div>
      </div>
      <div className="col-sm-6 col-lg-3 mb-7">
        <div className="service-item">
          <img className="service-icon" src="assets/images/icon/service2.png" alt="images_not_found" />
          <h3 className="service-title">TRUSTPAY</h3>
          <p>100% Payment Protection. Easy Return Policy</p>
        </div>
      </div>
      <div className="col-sm-6 col-lg-3 mb-7">
        <div className="service-item">
          <img className="service-icon" src="assets/images/icon/service3.png" alt="images_not_found" />
          <h3 className="service-title">HELP CENTER</h3>
          <p>GGot a question? Look no further.Browse our FAQs or submit your query here.</p>
        </div>
      </div>
      <div className="col-sm-6 col-lg-3 mb-7">
        <div className="service-item">
          <img className="service-icon" src="assets/images/icon/service4.png" alt="images_not_found" />
          <h3 className="service-title">Express Shipping</h3>
          <p>Fast, reliable delivery from global warehouses</p>
        </div>
      </div>
    </div>
  </div>
</div>
</section> */}
{/* service section end */}
{/* main content end */}
{/* footer section start */}
      </div>
    )
  }

  export default Milkegg;